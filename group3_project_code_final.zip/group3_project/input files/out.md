# Computing LERS!

 ## Iteration 1 

### CERTAIN RULES 



 | RULE | SUPPORT | CONFIDENCE |
| -- | -- | -- |
### POSSIBLE RULES


 | RULE | SUPPORT | CONFIDENCE |
| -- | -- | -- |
| (buying - high ) --> maint - high | 108 | 25.00 % |
| (buying - high ) --> maint - low | 108 | 25.00 % |
| (buying - high ) --> maint - vhigh | 108 | 25.00 % |
| (buying - high ) --> maint - med | 108 | 25.00 % |
| (buying - low ) --> maint - high | 108 | 25.00 % |
| (buying - low ) --> maint - low | 108 | 25.00 % |
| (buying - low ) --> maint - vhigh | 108 | 25.00 % |
| (buying - low ) --> maint - med | 108 | 25.00 % |
| (buying - vhigh ) --> maint - high | 108 | 25.00 % |
| (buying - vhigh ) --> maint - low | 108 | 25.00 % |
| (buying - vhigh ) --> maint - vhigh | 108 | 25.00 % |
| (buying - vhigh ) --> maint - med | 108 | 25.00 % |
| (buying - med ) --> maint - high | 108 | 25.00 % |
| (buying - med ) --> maint - low | 108 | 25.00 % |
| (buying - med ) --> maint - vhigh | 108 | 25.00 % |
| (buying - med ) --> maint - med | 108 | 25.00 % |
| (doors - 2 ) --> maint - high | 108 | 25.00 % |
| (doors - 2 ) --> maint - low | 108 | 25.00 % |
| (doors - 2 ) --> maint - vhigh | 108 | 25.00 % |
| (doors - 2 ) --> maint - med | 108 | 25.00 % |
| (doors - 3 ) --> maint - high | 108 | 25.00 % |
| (doors - 3 ) --> maint - low | 108 | 25.00 % |
| (doors - 3 ) --> maint - vhigh | 108 | 25.00 % |
| (doors - 3 ) --> maint - med | 108 | 25.00 % |
| (doors - 4 ) --> maint - high | 108 | 25.00 % |
| (doors - 4 ) --> maint - low | 108 | 25.00 % |
| (doors - 4 ) --> maint - vhigh | 108 | 25.00 % |
| (doors - 4 ) --> maint - med | 108 | 25.00 % |
| (doors - 5more ) --> maint - high | 108 | 25.00 % |
| (doors - 5more ) --> maint - low | 108 | 25.00 % |
| (doors - 5more ) --> maint - vhigh | 108 | 25.00 % |
| (doors - 5more ) --> maint - med | 108 | 25.00 % |
| (persons - 2 ) --> maint - high | 144 | 25.00 % |
| (persons - 2 ) --> maint - low | 144 | 25.00 % |
| (persons - 2 ) --> maint - vhigh | 144 | 25.00 % |
| (persons - 2 ) --> maint - med | 144 | 25.00 % |
| (persons - 4 ) --> maint - high | 144 | 25.00 % |
| (persons - 4 ) --> maint - low | 144 | 25.00 % |
| (persons - 4 ) --> maint - vhigh | 144 | 25.00 % |
| (persons - 4 ) --> maint - med | 144 | 25.00 % |
| (persons - more ) --> maint - high | 144 | 25.00 % |
| (persons - more ) --> maint - low | 144 | 25.00 % |
| (persons - more ) --> maint - vhigh | 144 | 25.00 % |
| (persons - more ) --> maint - med | 144 | 25.00 % |
| (lug_boot - small ) --> maint - high | 144 | 25.00 % |
| (lug_boot - small ) --> maint - low | 144 | 25.00 % |
| (lug_boot - small ) --> maint - vhigh | 144 | 25.00 % |
| (lug_boot - small ) --> maint - med | 144 | 25.00 % |
| (lug_boot - big ) --> maint - high | 144 | 25.00 % |
| (lug_boot - big ) --> maint - low | 144 | 25.00 % |
| (lug_boot - big ) --> maint - vhigh | 144 | 25.00 % |
| (lug_boot - big ) --> maint - med | 144 | 25.00 % |
| (lug_boot - med ) --> maint - high | 144 | 25.00 % |
| (lug_boot - med ) --> maint - low | 144 | 25.00 % |
| (lug_boot - med ) --> maint - vhigh | 144 | 25.00 % |
| (lug_boot - med ) --> maint - med | 144 | 25.00 % |
| (safety - high ) --> maint - high | 144 | 25.00 % |
| (safety - high ) --> maint - low | 144 | 25.00 % |
| (safety - high ) --> maint - vhigh | 144 | 25.00 % |
| (safety - high ) --> maint - med | 144 | 25.00 % |
| (safety - low ) --> maint - high | 144 | 25.00 % |
| (safety - low ) --> maint - low | 144 | 25.00 % |
| (safety - low ) --> maint - vhigh | 144 | 25.00 % |
| (safety - low ) --> maint - med | 144 | 25.00 % |
| (safety - med ) --> maint - high | 144 | 25.00 % |
| (safety - med ) --> maint - low | 144 | 25.00 % |
| (safety - med ) --> maint - vhigh | 144 | 25.00 % |
| (safety - med ) --> maint - med | 144 | 25.00 % |
| (class - acc ) --> maint - high | 105 | 27.34 % |
| (class - acc ) --> maint - med | 115 | 29.95 % |
| (class - unacc ) --> maint - high | 314 | 25.95 % |
| (class - unacc ) --> maint - vhigh | 360 | 29.75 % |
| (class - vgood ) --> maint - low | 26 | 40.00 % |
| (class - vgood ) --> maint - med | 26 | 40.00 % |
| (class - good ) --> maint - low | 46 | 66.67 % |
| (class - good ) --> maint - med | 23 | 33.33 % |

 ## Iteration 2 

### CERTAIN RULES 



 | RULE | SUPPORT | CONFIDENCE |
| -- | -- | -- |
| (buying - med, class - good ) --> maint - low | 23 | 100.00 % |
### POSSIBLE RULES


 | RULE | SUPPORT | CONFIDENCE |
| -- | -- | -- |
| (buying - high, doors - 2 ) --> maint - high | 27 | 25.00 % |
| (buying - high, doors - 2 ) --> maint - low | 27 | 25.00 % |
| (buying - high, doors - 2 ) --> maint - vhigh | 27 | 25.00 % |
| (buying - high, doors - 2 ) --> maint - med | 27 | 25.00 % |
| (buying - high, doors - 3 ) --> maint - high | 27 | 25.00 % |
| (buying - high, doors - 3 ) --> maint - low | 27 | 25.00 % |
| (buying - high, doors - 3 ) --> maint - vhigh | 27 | 25.00 % |
| (buying - high, doors - 3 ) --> maint - med | 27 | 25.00 % |
| (buying - high, doors - 4 ) --> maint - high | 27 | 25.00 % |
| (buying - high, doors - 4 ) --> maint - low | 27 | 25.00 % |
| (buying - high, doors - 4 ) --> maint - vhigh | 27 | 25.00 % |
| (buying - high, doors - 4 ) --> maint - med | 27 | 25.00 % |
| (buying - high, doors - 5more ) --> maint - high | 27 | 25.00 % |
| (buying - high, doors - 5more ) --> maint - low | 27 | 25.00 % |
| (buying - high, doors - 5more ) --> maint - vhigh | 27 | 25.00 % |
| (buying - high, doors - 5more ) --> maint - med | 27 | 25.00 % |
| (buying - high, persons - 2 ) --> maint - high | 36 | 25.00 % |
| (buying - high, persons - 2 ) --> maint - low | 36 | 25.00 % |
| (buying - high, persons - 2 ) --> maint - vhigh | 36 | 25.00 % |
| (buying - high, persons - 2 ) --> maint - med | 36 | 25.00 % |
| (buying - high, persons - 4 ) --> maint - high | 36 | 25.00 % |
| (buying - high, persons - 4 ) --> maint - low | 36 | 25.00 % |
| (buying - high, persons - 4 ) --> maint - vhigh | 36 | 25.00 % |
| (buying - high, persons - 4 ) --> maint - med | 36 | 25.00 % |
| (buying - high, persons - more ) --> maint - high | 36 | 25.00 % |
| (buying - high, persons - more ) --> maint - low | 36 | 25.00 % |
| (buying - high, persons - more ) --> maint - vhigh | 36 | 25.00 % |
| (buying - high, persons - more ) --> maint - med | 36 | 25.00 % |
| (buying - high, lug_boot - small ) --> maint - high | 36 | 25.00 % |
| (buying - high, lug_boot - small ) --> maint - low | 36 | 25.00 % |
| (buying - high, lug_boot - small ) --> maint - vhigh | 36 | 25.00 % |
| (buying - high, lug_boot - small ) --> maint - med | 36 | 25.00 % |
| (buying - high, lug_boot - big ) --> maint - high | 36 | 25.00 % |
| (buying - high, lug_boot - big ) --> maint - low | 36 | 25.00 % |
| (buying - high, lug_boot - big ) --> maint - vhigh | 36 | 25.00 % |
| (buying - high, lug_boot - big ) --> maint - med | 36 | 25.00 % |
| (buying - high, lug_boot - med ) --> maint - high | 36 | 25.00 % |
| (buying - high, lug_boot - med ) --> maint - low | 36 | 25.00 % |
| (buying - high, lug_boot - med ) --> maint - vhigh | 36 | 25.00 % |
| (buying - high, lug_boot - med ) --> maint - med | 36 | 25.00 % |
| (buying - high, safety - high ) --> maint - high | 36 | 25.00 % |
| (buying - high, safety - high ) --> maint - low | 36 | 25.00 % |
| (buying - high, safety - high ) --> maint - vhigh | 36 | 25.00 % |
| (buying - high, safety - high ) --> maint - med | 36 | 25.00 % |
| (buying - high, safety - low ) --> maint - high | 36 | 25.00 % |
| (buying - high, safety - low ) --> maint - low | 36 | 25.00 % |
| (buying - high, safety - low ) --> maint - vhigh | 36 | 25.00 % |
| (buying - high, safety - low ) --> maint - med | 36 | 25.00 % |
| (buying - high, safety - med ) --> maint - high | 36 | 25.00 % |
| (buying - high, safety - med ) --> maint - low | 36 | 25.00 % |
| (buying - high, safety - med ) --> maint - vhigh | 36 | 25.00 % |
| (buying - high, safety - med ) --> maint - med | 36 | 25.00 % |
| (buying - high, class - acc ) --> maint - high | 36 | 33.33 % |
| (buying - high, class - acc ) --> maint - low | 36 | 33.33 % |
| (buying - high, class - acc ) --> maint - med | 36 | 33.33 % |
| (buying - high, class - unacc ) --> maint - vhigh | 108 | 33.33 % |
| (buying - low, doors - 2 ) --> maint - high | 27 | 25.00 % |
| (buying - low, doors - 2 ) --> maint - low | 27 | 25.00 % |
| (buying - low, doors - 2 ) --> maint - vhigh | 27 | 25.00 % |
| (buying - low, doors - 2 ) --> maint - med | 27 | 25.00 % |
| (buying - low, doors - 3 ) --> maint - high | 27 | 25.00 % |
| (buying - low, doors - 3 ) --> maint - low | 27 | 25.00 % |
| (buying - low, doors - 3 ) --> maint - vhigh | 27 | 25.00 % |
| (buying - low, doors - 3 ) --> maint - med | 27 | 25.00 % |
| (buying - low, doors - 4 ) --> maint - high | 27 | 25.00 % |
| (buying - low, doors - 4 ) --> maint - low | 27 | 25.00 % |
| (buying - low, doors - 4 ) --> maint - vhigh | 27 | 25.00 % |
| (buying - low, doors - 4 ) --> maint - med | 27 | 25.00 % |
| (buying - low, doors - 5more ) --> maint - high | 27 | 25.00 % |
| (buying - low, doors - 5more ) --> maint - low | 27 | 25.00 % |
| (buying - low, doors - 5more ) --> maint - vhigh | 27 | 25.00 % |
| (buying - low, doors - 5more ) --> maint - med | 27 | 25.00 % |
| (buying - low, persons - 2 ) --> maint - high | 36 | 25.00 % |
| (buying - low, persons - 2 ) --> maint - low | 36 | 25.00 % |
| (buying - low, persons - 2 ) --> maint - vhigh | 36 | 25.00 % |
| (buying - low, persons - 2 ) --> maint - med | 36 | 25.00 % |
| (buying - low, persons - 4 ) --> maint - high | 36 | 25.00 % |
| (buying - low, persons - 4 ) --> maint - low | 36 | 25.00 % |
| (buying - low, persons - 4 ) --> maint - vhigh | 36 | 25.00 % |
| (buying - low, persons - 4 ) --> maint - med | 36 | 25.00 % |
| (buying - low, persons - more ) --> maint - high | 36 | 25.00 % |
| (buying - low, persons - more ) --> maint - low | 36 | 25.00 % |
| (buying - low, persons - more ) --> maint - vhigh | 36 | 25.00 % |
| (buying - low, persons - more ) --> maint - med | 36 | 25.00 % |
| (buying - low, lug_boot - small ) --> maint - high | 36 | 25.00 % |
| (buying - low, lug_boot - small ) --> maint - low | 36 | 25.00 % |
| (buying - low, lug_boot - small ) --> maint - vhigh | 36 | 25.00 % |
| (buying - low, lug_boot - small ) --> maint - med | 36 | 25.00 % |
| (buying - low, lug_boot - big ) --> maint - high | 36 | 25.00 % |
| (buying - low, lug_boot - big ) --> maint - low | 36 | 25.00 % |
| (buying - low, lug_boot - big ) --> maint - vhigh | 36 | 25.00 % |
| (buying - low, lug_boot - big ) --> maint - med | 36 | 25.00 % |
| (buying - low, lug_boot - med ) --> maint - high | 36 | 25.00 % |
| (buying - low, lug_boot - med ) --> maint - low | 36 | 25.00 % |
| (buying - low, lug_boot - med ) --> maint - vhigh | 36 | 25.00 % |
| (buying - low, lug_boot - med ) --> maint - med | 36 | 25.00 % |
| (buying - low, safety - high ) --> maint - high | 36 | 25.00 % |
| (buying - low, safety - high ) --> maint - low | 36 | 25.00 % |
| (buying - low, safety - high ) --> maint - vhigh | 36 | 25.00 % |
| (buying - low, safety - high ) --> maint - med | 36 | 25.00 % |
| (buying - low, safety - low ) --> maint - high | 36 | 25.00 % |
| (buying - low, safety - low ) --> maint - low | 36 | 25.00 % |
| (buying - low, safety - low ) --> maint - vhigh | 36 | 25.00 % |
| (buying - low, safety - low ) --> maint - med | 36 | 25.00 % |
| (buying - low, safety - med ) --> maint - high | 36 | 25.00 % |
| (buying - low, safety - med ) --> maint - low | 36 | 25.00 % |
| (buying - low, safety - med ) --> maint - vhigh | 36 | 25.00 % |
| (buying - low, safety - med ) --> maint - med | 36 | 25.00 % |
| (buying - low, class - acc ) --> maint - high | 33 | 37.08 % |
| (buying - low, class - acc ) --> maint - vhigh | 36 | 40.45 % |
| (buying - low, class - unacc ) --> maint - vhigh | 72 | 27.91 % |
| (buying - low, class - good ) --> maint - low | 23 | 50.00 % |
| (buying - low, class - good ) --> maint - med | 23 | 50.00 % |
| (buying - vhigh, doors - 2 ) --> maint - high | 27 | 25.00 % |
| (buying - vhigh, doors - 2 ) --> maint - low | 27 | 25.00 % |
| (buying - vhigh, doors - 2 ) --> maint - vhigh | 27 | 25.00 % |
| (buying - vhigh, doors - 2 ) --> maint - med | 27 | 25.00 % |
| (buying - vhigh, doors - 3 ) --> maint - high | 27 | 25.00 % |
| (buying - vhigh, doors - 3 ) --> maint - low | 27 | 25.00 % |
| (buying - vhigh, doors - 3 ) --> maint - vhigh | 27 | 25.00 % |
| (buying - vhigh, doors - 3 ) --> maint - med | 27 | 25.00 % |
| (buying - vhigh, doors - 4 ) --> maint - high | 27 | 25.00 % |
| (buying - vhigh, doors - 4 ) --> maint - low | 27 | 25.00 % |
| (buying - vhigh, doors - 4 ) --> maint - vhigh | 27 | 25.00 % |
| (buying - vhigh, doors - 4 ) --> maint - med | 27 | 25.00 % |
| (buying - vhigh, doors - 5more ) --> maint - high | 27 | 25.00 % |
| (buying - vhigh, doors - 5more ) --> maint - low | 27 | 25.00 % |
| (buying - vhigh, doors - 5more ) --> maint - vhigh | 27 | 25.00 % |
| (buying - vhigh, doors - 5more ) --> maint - med | 27 | 25.00 % |
| (buying - vhigh, persons - 2 ) --> maint - high | 36 | 25.00 % |
| (buying - vhigh, persons - 2 ) --> maint - low | 36 | 25.00 % |
| (buying - vhigh, persons - 2 ) --> maint - vhigh | 36 | 25.00 % |
| (buying - vhigh, persons - 2 ) --> maint - med | 36 | 25.00 % |
| (buying - vhigh, persons - 4 ) --> maint - high | 36 | 25.00 % |
| (buying - vhigh, persons - 4 ) --> maint - low | 36 | 25.00 % |
| (buying - vhigh, persons - 4 ) --> maint - vhigh | 36 | 25.00 % |
| (buying - vhigh, persons - 4 ) --> maint - med | 36 | 25.00 % |
| (buying - vhigh, persons - more ) --> maint - high | 36 | 25.00 % |
| (buying - vhigh, persons - more ) --> maint - low | 36 | 25.00 % |
| (buying - vhigh, persons - more ) --> maint - vhigh | 36 | 25.00 % |
| (buying - vhigh, persons - more ) --> maint - med | 36 | 25.00 % |
| (buying - vhigh, lug_boot - small ) --> maint - high | 36 | 25.00 % |
| (buying - vhigh, lug_boot - small ) --> maint - low | 36 | 25.00 % |
| (buying - vhigh, lug_boot - small ) --> maint - vhigh | 36 | 25.00 % |
| (buying - vhigh, lug_boot - small ) --> maint - med | 36 | 25.00 % |
| (buying - vhigh, lug_boot - big ) --> maint - high | 36 | 25.00 % |
| (buying - vhigh, lug_boot - big ) --> maint - low | 36 | 25.00 % |
| (buying - vhigh, lug_boot - big ) --> maint - vhigh | 36 | 25.00 % |
| (buying - vhigh, lug_boot - big ) --> maint - med | 36 | 25.00 % |
| (buying - vhigh, lug_boot - med ) --> maint - high | 36 | 25.00 % |
| (buying - vhigh, lug_boot - med ) --> maint - low | 36 | 25.00 % |
| (buying - vhigh, lug_boot - med ) --> maint - vhigh | 36 | 25.00 % |
| (buying - vhigh, lug_boot - med ) --> maint - med | 36 | 25.00 % |
| (buying - vhigh, safety - high ) --> maint - high | 36 | 25.00 % |
| (buying - vhigh, safety - high ) --> maint - low | 36 | 25.00 % |
| (buying - vhigh, safety - high ) --> maint - vhigh | 36 | 25.00 % |
| (buying - vhigh, safety - high ) --> maint - med | 36 | 25.00 % |
| (buying - vhigh, safety - low ) --> maint - high | 36 | 25.00 % |
| (buying - vhigh, safety - low ) --> maint - low | 36 | 25.00 % |
| (buying - vhigh, safety - low ) --> maint - vhigh | 36 | 25.00 % |
| (buying - vhigh, safety - low ) --> maint - med | 36 | 25.00 % |
| (buying - vhigh, safety - med ) --> maint - high | 36 | 25.00 % |
| (buying - vhigh, safety - med ) --> maint - low | 36 | 25.00 % |
| (buying - vhigh, safety - med ) --> maint - vhigh | 36 | 25.00 % |
| (buying - vhigh, safety - med ) --> maint - med | 36 | 25.00 % |
| (buying - vhigh, class - acc ) --> maint - low | 36 | 50.00 % |
| (buying - vhigh, class - acc ) --> maint - med | 36 | 50.00 % |
| (buying - vhigh, class - unacc ) --> maint - high | 108 | 30.00 % |
| (buying - vhigh, class - unacc ) --> maint - vhigh | 108 | 30.00 % |
| (buying - med, doors - 2 ) --> maint - high | 27 | 25.00 % |
| (buying - med, doors - 2 ) --> maint - low | 27 | 25.00 % |
| (buying - med, doors - 2 ) --> maint - vhigh | 27 | 25.00 % |
| (buying - med, doors - 2 ) --> maint - med | 27 | 25.00 % |
| (buying - med, doors - 3 ) --> maint - high | 27 | 25.00 % |
| (buying - med, doors - 3 ) --> maint - low | 27 | 25.00 % |
| (buying - med, doors - 3 ) --> maint - vhigh | 27 | 25.00 % |
| (buying - med, doors - 3 ) --> maint - med | 27 | 25.00 % |
| (buying - med, doors - 4 ) --> maint - high | 27 | 25.00 % |
| (buying - med, doors - 4 ) --> maint - low | 27 | 25.00 % |
| (buying - med, doors - 4 ) --> maint - vhigh | 27 | 25.00 % |
| (buying - med, doors - 4 ) --> maint - med | 27 | 25.00 % |
| (buying - med, doors - 5more ) --> maint - high | 27 | 25.00 % |
| (buying - med, doors - 5more ) --> maint - low | 27 | 25.00 % |
| (buying - med, doors - 5more ) --> maint - vhigh | 27 | 25.00 % |
| (buying - med, doors - 5more ) --> maint - med | 27 | 25.00 % |
| (buying - med, persons - 2 ) --> maint - high | 36 | 25.00 % |
| (buying - med, persons - 2 ) --> maint - low | 36 | 25.00 % |
| (buying - med, persons - 2 ) --> maint - vhigh | 36 | 25.00 % |
| (buying - med, persons - 2 ) --> maint - med | 36 | 25.00 % |
| (buying - med, persons - 4 ) --> maint - high | 36 | 25.00 % |
| (buying - med, persons - 4 ) --> maint - low | 36 | 25.00 % |
| (buying - med, persons - 4 ) --> maint - vhigh | 36 | 25.00 % |
| (buying - med, persons - 4 ) --> maint - med | 36 | 25.00 % |
| (buying - med, persons - more ) --> maint - high | 36 | 25.00 % |
| (buying - med, persons - more ) --> maint - low | 36 | 25.00 % |
| (buying - med, persons - more ) --> maint - vhigh | 36 | 25.00 % |
| (buying - med, persons - more ) --> maint - med | 36 | 25.00 % |
| (buying - med, lug_boot - small ) --> maint - high | 36 | 25.00 % |
| (buying - med, lug_boot - small ) --> maint - low | 36 | 25.00 % |
| (buying - med, lug_boot - small ) --> maint - vhigh | 36 | 25.00 % |
| (buying - med, lug_boot - small ) --> maint - med | 36 | 25.00 % |
| (buying - med, lug_boot - big ) --> maint - high | 36 | 25.00 % |
| (buying - med, lug_boot - big ) --> maint - low | 36 | 25.00 % |
| (buying - med, lug_boot - big ) --> maint - vhigh | 36 | 25.00 % |
| (buying - med, lug_boot - big ) --> maint - med | 36 | 25.00 % |
| (buying - med, lug_boot - med ) --> maint - high | 36 | 25.00 % |
| (buying - med, lug_boot - med ) --> maint - low | 36 | 25.00 % |
| (buying - med, lug_boot - med ) --> maint - vhigh | 36 | 25.00 % |
| (buying - med, lug_boot - med ) --> maint - med | 36 | 25.00 % |
| (buying - med, safety - high ) --> maint - high | 36 | 25.00 % |
| (buying - med, safety - high ) --> maint - low | 36 | 25.00 % |
| (buying - med, safety - high ) --> maint - vhigh | 36 | 25.00 % |
| (buying - med, safety - high ) --> maint - med | 36 | 25.00 % |
| (buying - med, safety - low ) --> maint - high | 36 | 25.00 % |
| (buying - med, safety - low ) --> maint - low | 36 | 25.00 % |
| (buying - med, safety - low ) --> maint - vhigh | 36 | 25.00 % |
| (buying - med, safety - low ) --> maint - med | 36 | 25.00 % |
| (buying - med, safety - med ) --> maint - high | 36 | 25.00 % |
| (buying - med, safety - med ) --> maint - low | 36 | 25.00 % |
| (buying - med, safety - med ) --> maint - vhigh | 36 | 25.00 % |
| (buying - med, safety - med ) --> maint - med | 36 | 25.00 % |
| (buying - med, class - acc ) --> maint - high | 36 | 31.30 % |
| (buying - med, class - acc ) --> maint - vhigh | 36 | 31.30 % |
| (buying - med, class - acc ) --> maint - med | 33 | 28.70 % |
| (buying - med, class - unacc ) --> maint - high | 72 | 26.87 % |
| (buying - med, class - unacc ) --> maint - vhigh | 72 | 26.87 % |
| (doors - 2, persons - 2 ) --> maint - high | 36 | 25.00 % |
| (doors - 2, persons - 2 ) --> maint - low | 36 | 25.00 % |
| (doors - 2, persons - 2 ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 2, persons - 2 ) --> maint - med | 36 | 25.00 % |
| (doors - 2, persons - 4 ) --> maint - high | 36 | 25.00 % |
| (doors - 2, persons - 4 ) --> maint - low | 36 | 25.00 % |
| (doors - 2, persons - 4 ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 2, persons - 4 ) --> maint - med | 36 | 25.00 % |
| (doors - 2, persons - more ) --> maint - high | 36 | 25.00 % |
| (doors - 2, persons - more ) --> maint - low | 36 | 25.00 % |
| (doors - 2, persons - more ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 2, persons - more ) --> maint - med | 36 | 25.00 % |
| (doors - 2, lug_boot - small ) --> maint - high | 36 | 25.00 % |
| (doors - 2, lug_boot - small ) --> maint - low | 36 | 25.00 % |
| (doors - 2, lug_boot - small ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 2, lug_boot - small ) --> maint - med | 36 | 25.00 % |
| (doors - 2, lug_boot - big ) --> maint - high | 36 | 25.00 % |
| (doors - 2, lug_boot - big ) --> maint - low | 36 | 25.00 % |
| (doors - 2, lug_boot - big ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 2, lug_boot - big ) --> maint - med | 36 | 25.00 % |
| (doors - 2, lug_boot - med ) --> maint - high | 36 | 25.00 % |
| (doors - 2, lug_boot - med ) --> maint - low | 36 | 25.00 % |
| (doors - 2, lug_boot - med ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 2, lug_boot - med ) --> maint - med | 36 | 25.00 % |
| (doors - 2, safety - high ) --> maint - high | 36 | 25.00 % |
| (doors - 2, safety - high ) --> maint - low | 36 | 25.00 % |
| (doors - 2, safety - high ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 2, safety - high ) --> maint - med | 36 | 25.00 % |
| (doors - 2, safety - low ) --> maint - high | 36 | 25.00 % |
| (doors - 2, safety - low ) --> maint - low | 36 | 25.00 % |
| (doors - 2, safety - low ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 2, safety - low ) --> maint - med | 36 | 25.00 % |
| (doors - 2, safety - med ) --> maint - high | 36 | 25.00 % |
| (doors - 2, safety - med ) --> maint - low | 36 | 25.00 % |
| (doors - 2, safety - med ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 2, safety - med ) --> maint - med | 36 | 25.00 % |
| (doors - 2, class - acc ) --> maint - high | 22 | 27.16 % |
| (doors - 2, class - acc ) --> maint - med | 25 | 30.86 % |
| (doors - 2, class - unacc ) --> maint - high | 84 | 25.77 % |
| (doors - 2, class - unacc ) --> maint - vhigh | 94 | 28.83 % |
| (doors - 3, persons - 2 ) --> maint - high | 36 | 25.00 % |
| (doors - 3, persons - 2 ) --> maint - low | 36 | 25.00 % |
| (doors - 3, persons - 2 ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 3, persons - 2 ) --> maint - med | 36 | 25.00 % |
| (doors - 3, persons - 4 ) --> maint - high | 36 | 25.00 % |
| (doors - 3, persons - 4 ) --> maint - low | 36 | 25.00 % |
| (doors - 3, persons - 4 ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 3, persons - 4 ) --> maint - med | 36 | 25.00 % |
| (doors - 3, persons - more ) --> maint - high | 36 | 25.00 % |
| (doors - 3, persons - more ) --> maint - low | 36 | 25.00 % |
| (doors - 3, persons - more ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 3, persons - more ) --> maint - med | 36 | 25.00 % |
| (doors - 3, lug_boot - small ) --> maint - high | 36 | 25.00 % |
| (doors - 3, lug_boot - small ) --> maint - low | 36 | 25.00 % |
| (doors - 3, lug_boot - small ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 3, lug_boot - small ) --> maint - med | 36 | 25.00 % |
| (doors - 3, lug_boot - big ) --> maint - high | 36 | 25.00 % |
| (doors - 3, lug_boot - big ) --> maint - low | 36 | 25.00 % |
| (doors - 3, lug_boot - big ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 3, lug_boot - big ) --> maint - med | 36 | 25.00 % |
| (doors - 3, lug_boot - med ) --> maint - high | 36 | 25.00 % |
| (doors - 3, lug_boot - med ) --> maint - low | 36 | 25.00 % |
| (doors - 3, lug_boot - med ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 3, lug_boot - med ) --> maint - med | 36 | 25.00 % |
| (doors - 3, safety - high ) --> maint - high | 36 | 25.00 % |
| (doors - 3, safety - high ) --> maint - low | 36 | 25.00 % |
| (doors - 3, safety - high ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 3, safety - high ) --> maint - med | 36 | 25.00 % |
| (doors - 3, safety - low ) --> maint - high | 36 | 25.00 % |
| (doors - 3, safety - low ) --> maint - low | 36 | 25.00 % |
| (doors - 3, safety - low ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 3, safety - low ) --> maint - med | 36 | 25.00 % |
| (doors - 3, safety - med ) --> maint - high | 36 | 25.00 % |
| (doors - 3, safety - med ) --> maint - low | 36 | 25.00 % |
| (doors - 3, safety - med ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 3, safety - med ) --> maint - med | 36 | 25.00 % |
| (doors - 3, class - acc ) --> maint - high | 27 | 27.27 % |
| (doors - 3, class - acc ) --> maint - med | 30 | 30.30 % |
| (doors - 3, class - unacc ) --> maint - high | 78 | 26.00 % |
| (doors - 3, class - unacc ) --> maint - vhigh | 90 | 30.00 % |
| (doors - 4, persons - 2 ) --> maint - high | 36 | 25.00 % |
| (doors - 4, persons - 2 ) --> maint - low | 36 | 25.00 % |
| (doors - 4, persons - 2 ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 4, persons - 2 ) --> maint - med | 36 | 25.00 % |
| (doors - 4, persons - 4 ) --> maint - high | 36 | 25.00 % |
| (doors - 4, persons - 4 ) --> maint - low | 36 | 25.00 % |
| (doors - 4, persons - 4 ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 4, persons - 4 ) --> maint - med | 36 | 25.00 % |
| (doors - 4, persons - more ) --> maint - high | 36 | 25.00 % |
| (doors - 4, persons - more ) --> maint - low | 36 | 25.00 % |
| (doors - 4, persons - more ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 4, persons - more ) --> maint - med | 36 | 25.00 % |
| (doors - 4, lug_boot - small ) --> maint - high | 36 | 25.00 % |
| (doors - 4, lug_boot - small ) --> maint - low | 36 | 25.00 % |
| (doors - 4, lug_boot - small ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 4, lug_boot - small ) --> maint - med | 36 | 25.00 % |
| (doors - 4, lug_boot - big ) --> maint - high | 36 | 25.00 % |
| (doors - 4, lug_boot - big ) --> maint - low | 36 | 25.00 % |
| (doors - 4, lug_boot - big ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 4, lug_boot - big ) --> maint - med | 36 | 25.00 % |
| (doors - 4, lug_boot - med ) --> maint - high | 36 | 25.00 % |
| (doors - 4, lug_boot - med ) --> maint - low | 36 | 25.00 % |
| (doors - 4, lug_boot - med ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 4, lug_boot - med ) --> maint - med | 36 | 25.00 % |
| (doors - 4, safety - high ) --> maint - high | 36 | 25.00 % |
| (doors - 4, safety - high ) --> maint - low | 36 | 25.00 % |
| (doors - 4, safety - high ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 4, safety - high ) --> maint - med | 36 | 25.00 % |
| (doors - 4, safety - low ) --> maint - high | 36 | 25.00 % |
| (doors - 4, safety - low ) --> maint - low | 36 | 25.00 % |
| (doors - 4, safety - low ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 4, safety - low ) --> maint - med | 36 | 25.00 % |
| (doors - 4, safety - med ) --> maint - high | 36 | 25.00 % |
| (doors - 4, safety - med ) --> maint - low | 36 | 25.00 % |
| (doors - 4, safety - med ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 4, safety - med ) --> maint - med | 36 | 25.00 % |
| (doors - 4, class - acc ) --> maint - high | 28 | 27.45 % |
| (doors - 4, class - acc ) --> maint - med | 30 | 29.41 % |
| (doors - 4, class - unacc ) --> maint - high | 76 | 26.03 % |
| (doors - 4, class - unacc ) --> maint - vhigh | 88 | 30.14 % |
| (doors - 5more, persons - 2 ) --> maint - high | 36 | 25.00 % |
| (doors - 5more, persons - 2 ) --> maint - low | 36 | 25.00 % |
| (doors - 5more, persons - 2 ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 5more, persons - 2 ) --> maint - med | 36 | 25.00 % |
| (doors - 5more, persons - 4 ) --> maint - high | 36 | 25.00 % |
| (doors - 5more, persons - 4 ) --> maint - low | 36 | 25.00 % |
| (doors - 5more, persons - 4 ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 5more, persons - 4 ) --> maint - med | 36 | 25.00 % |
| (doors - 5more, persons - more ) --> maint - high | 36 | 25.00 % |
| (doors - 5more, persons - more ) --> maint - low | 36 | 25.00 % |
| (doors - 5more, persons - more ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 5more, persons - more ) --> maint - med | 36 | 25.00 % |
| (doors - 5more, lug_boot - small ) --> maint - high | 36 | 25.00 % |
| (doors - 5more, lug_boot - small ) --> maint - low | 36 | 25.00 % |
| (doors - 5more, lug_boot - small ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 5more, lug_boot - small ) --> maint - med | 36 | 25.00 % |
| (doors - 5more, lug_boot - big ) --> maint - high | 36 | 25.00 % |
| (doors - 5more, lug_boot - big ) --> maint - low | 36 | 25.00 % |
| (doors - 5more, lug_boot - big ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 5more, lug_boot - big ) --> maint - med | 36 | 25.00 % |
| (doors - 5more, lug_boot - med ) --> maint - high | 36 | 25.00 % |
| (doors - 5more, lug_boot - med ) --> maint - low | 36 | 25.00 % |
| (doors - 5more, lug_boot - med ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 5more, lug_boot - med ) --> maint - med | 36 | 25.00 % |
| (doors - 5more, safety - high ) --> maint - high | 36 | 25.00 % |
| (doors - 5more, safety - high ) --> maint - low | 36 | 25.00 % |
| (doors - 5more, safety - high ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 5more, safety - high ) --> maint - med | 36 | 25.00 % |
| (doors - 5more, safety - low ) --> maint - high | 36 | 25.00 % |
| (doors - 5more, safety - low ) --> maint - low | 36 | 25.00 % |
| (doors - 5more, safety - low ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 5more, safety - low ) --> maint - med | 36 | 25.00 % |
| (doors - 5more, safety - med ) --> maint - high | 36 | 25.00 % |
| (doors - 5more, safety - med ) --> maint - low | 36 | 25.00 % |
| (doors - 5more, safety - med ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 5more, safety - med ) --> maint - med | 36 | 25.00 % |
| (doors - 5more, class - acc ) --> maint - high | 28 | 27.45 % |
| (doors - 5more, class - acc ) --> maint - med | 30 | 29.41 % |
| (doors - 5more, class - unacc ) --> maint - high | 76 | 26.03 % |
| (doors - 5more, class - unacc ) --> maint - vhigh | 88 | 30.14 % |
| (persons - 2, lug_boot - small ) --> maint - high | 48 | 25.00 % |
| (persons - 2, lug_boot - small ) --> maint - low | 48 | 25.00 % |
| (persons - 2, lug_boot - small ) --> maint - vhigh | 48 | 25.00 % |
| (persons - 2, lug_boot - small ) --> maint - med | 48 | 25.00 % |
| (persons - 2, lug_boot - big ) --> maint - high | 48 | 25.00 % |
| (persons - 2, lug_boot - big ) --> maint - low | 48 | 25.00 % |
| (persons - 2, lug_boot - big ) --> maint - vhigh | 48 | 25.00 % |
| (persons - 2, lug_boot - big ) --> maint - med | 48 | 25.00 % |
| (persons - 2, lug_boot - med ) --> maint - high | 48 | 25.00 % |
| (persons - 2, lug_boot - med ) --> maint - low | 48 | 25.00 % |
| (persons - 2, lug_boot - med ) --> maint - vhigh | 48 | 25.00 % |
| (persons - 2, lug_boot - med ) --> maint - med | 48 | 25.00 % |
| (persons - 2, safety - high ) --> maint - high | 48 | 25.00 % |
| (persons - 2, safety - high ) --> maint - low | 48 | 25.00 % |
| (persons - 2, safety - high ) --> maint - vhigh | 48 | 25.00 % |
| (persons - 2, safety - high ) --> maint - med | 48 | 25.00 % |
| (persons - 2, safety - low ) --> maint - high | 48 | 25.00 % |
| (persons - 2, safety - low ) --> maint - low | 48 | 25.00 % |
| (persons - 2, safety - low ) --> maint - vhigh | 48 | 25.00 % |
| (persons - 2, safety - low ) --> maint - med | 48 | 25.00 % |
| (persons - 2, safety - med ) --> maint - high | 48 | 25.00 % |
| (persons - 2, safety - med ) --> maint - low | 48 | 25.00 % |
| (persons - 2, safety - med ) --> maint - vhigh | 48 | 25.00 % |
| (persons - 2, safety - med ) --> maint - med | 48 | 25.00 % |
| (persons - 2, class - unacc ) --> maint - high | 144 | 25.00 % |
| (persons - 2, class - unacc ) --> maint - low | 144 | 25.00 % |
| (persons - 2, class - unacc ) --> maint - vhigh | 144 | 25.00 % |
| (persons - 2, class - unacc ) --> maint - med | 144 | 25.00 % |
| (persons - 4, lug_boot - small ) --> maint - high | 48 | 25.00 % |
| (persons - 4, lug_boot - small ) --> maint - low | 48 | 25.00 % |
| (persons - 4, lug_boot - small ) --> maint - vhigh | 48 | 25.00 % |
| (persons - 4, lug_boot - small ) --> maint - med | 48 | 25.00 % |
| (persons - 4, lug_boot - big ) --> maint - high | 48 | 25.00 % |
| (persons - 4, lug_boot - big ) --> maint - low | 48 | 25.00 % |
| (persons - 4, lug_boot - big ) --> maint - vhigh | 48 | 25.00 % |
| (persons - 4, lug_boot - big ) --> maint - med | 48 | 25.00 % |
| (persons - 4, lug_boot - med ) --> maint - high | 48 | 25.00 % |
| (persons - 4, lug_boot - med ) --> maint - low | 48 | 25.00 % |
| (persons - 4, lug_boot - med ) --> maint - vhigh | 48 | 25.00 % |
| (persons - 4, lug_boot - med ) --> maint - med | 48 | 25.00 % |
| (persons - 4, safety - high ) --> maint - high | 48 | 25.00 % |
| (persons - 4, safety - high ) --> maint - low | 48 | 25.00 % |
| (persons - 4, safety - high ) --> maint - vhigh | 48 | 25.00 % |
| (persons - 4, safety - high ) --> maint - med | 48 | 25.00 % |
| (persons - 4, safety - low ) --> maint - high | 48 | 25.00 % |
| (persons - 4, safety - low ) --> maint - low | 48 | 25.00 % |
| (persons - 4, safety - low ) --> maint - vhigh | 48 | 25.00 % |
| (persons - 4, safety - low ) --> maint - med | 48 | 25.00 % |
| (persons - 4, safety - med ) --> maint - high | 48 | 25.00 % |
| (persons - 4, safety - med ) --> maint - low | 48 | 25.00 % |
| (persons - 4, safety - med ) --> maint - vhigh | 48 | 25.00 % |
| (persons - 4, safety - med ) --> maint - med | 48 | 25.00 % |
| (persons - 4, class - acc ) --> maint - high | 54 | 27.27 % |
| (persons - 4, class - acc ) --> maint - med | 60 | 30.30 % |
| (persons - 4, class - unacc ) --> maint - high | 84 | 26.92 % |
| (persons - 4, class - unacc ) --> maint - vhigh | 108 | 34.62 % |
| (persons - 4, class - good ) --> maint - low | 24 | 66.67 % |
| (persons - more, lug_boot - small ) --> maint - high | 48 | 25.00 % |
| (persons - more, lug_boot - small ) --> maint - low | 48 | 25.00 % |
| (persons - more, lug_boot - small ) --> maint - vhigh | 48 | 25.00 % |
| (persons - more, lug_boot - small ) --> maint - med | 48 | 25.00 % |
| (persons - more, lug_boot - big ) --> maint - high | 48 | 25.00 % |
| (persons - more, lug_boot - big ) --> maint - low | 48 | 25.00 % |
| (persons - more, lug_boot - big ) --> maint - vhigh | 48 | 25.00 % |
| (persons - more, lug_boot - big ) --> maint - med | 48 | 25.00 % |
| (persons - more, lug_boot - med ) --> maint - high | 48 | 25.00 % |
| (persons - more, lug_boot - med ) --> maint - low | 48 | 25.00 % |
| (persons - more, lug_boot - med ) --> maint - vhigh | 48 | 25.00 % |
| (persons - more, lug_boot - med ) --> maint - med | 48 | 25.00 % |
| (persons - more, safety - high ) --> maint - high | 48 | 25.00 % |
| (persons - more, safety - high ) --> maint - low | 48 | 25.00 % |
| (persons - more, safety - high ) --> maint - vhigh | 48 | 25.00 % |
| (persons - more, safety - high ) --> maint - med | 48 | 25.00 % |
| (persons - more, safety - low ) --> maint - high | 48 | 25.00 % |
| (persons - more, safety - low ) --> maint - low | 48 | 25.00 % |
| (persons - more, safety - low ) --> maint - vhigh | 48 | 25.00 % |
| (persons - more, safety - low ) --> maint - med | 48 | 25.00 % |
| (persons - more, safety - med ) --> maint - high | 48 | 25.00 % |
| (persons - more, safety - med ) --> maint - low | 48 | 25.00 % |
| (persons - more, safety - med ) --> maint - vhigh | 48 | 25.00 % |
| (persons - more, safety - med ) --> maint - med | 48 | 25.00 % |
| (persons - more, class - acc ) --> maint - high | 51 | 27.42 % |
| (persons - more, class - acc ) --> maint - med | 55 | 29.57 % |
| (persons - more, class - unacc ) --> maint - high | 86 | 26.71 % |
| (persons - more, class - unacc ) --> maint - vhigh | 108 | 33.54 % |
| (persons - more, class - good ) --> maint - low | 22 | 66.67 % |
| (lug_boot - small, safety - high ) --> maint - high | 48 | 25.00 % |
| (lug_boot - small, safety - high ) --> maint - low | 48 | 25.00 % |
| (lug_boot - small, safety - high ) --> maint - vhigh | 48 | 25.00 % |
| (lug_boot - small, safety - high ) --> maint - med | 48 | 25.00 % |
| (lug_boot - small, safety - low ) --> maint - high | 48 | 25.00 % |
| (lug_boot - small, safety - low ) --> maint - low | 48 | 25.00 % |
| (lug_boot - small, safety - low ) --> maint - vhigh | 48 | 25.00 % |
| (lug_boot - small, safety - low ) --> maint - med | 48 | 25.00 % |
| (lug_boot - small, safety - med ) --> maint - high | 48 | 25.00 % |
| (lug_boot - small, safety - med ) --> maint - low | 48 | 25.00 % |
| (lug_boot - small, safety - med ) --> maint - vhigh | 48 | 25.00 % |
| (lug_boot - small, safety - med ) --> maint - med | 48 | 25.00 % |
| (lug_boot - small, class - acc ) --> maint - high | 28 | 26.67 % |
| (lug_boot - small, class - acc ) --> maint - low | 28 | 26.67 % |
| (lug_boot - small, class - acc ) --> maint - med | 35 | 33.33 % |
| (lug_boot - small, class - unacc ) --> maint - high | 116 | 25.78 % |
| (lug_boot - small, class - unacc ) --> maint - vhigh | 130 | 28.89 % |
| (lug_boot - big, safety - high ) --> maint - high | 48 | 25.00 % |
| (lug_boot - big, safety - high ) --> maint - low | 48 | 25.00 % |
| (lug_boot - big, safety - high ) --> maint - vhigh | 48 | 25.00 % |
| (lug_boot - big, safety - high ) --> maint - med | 48 | 25.00 % |
| (lug_boot - big, safety - low ) --> maint - high | 48 | 25.00 % |
| (lug_boot - big, safety - low ) --> maint - low | 48 | 25.00 % |
| (lug_boot - big, safety - low ) --> maint - vhigh | 48 | 25.00 % |
| (lug_boot - big, safety - low ) --> maint - med | 48 | 25.00 % |
| (lug_boot - big, safety - med ) --> maint - high | 48 | 25.00 % |
| (lug_boot - big, safety - med ) --> maint - low | 48 | 25.00 % |
| (lug_boot - big, safety - med ) --> maint - vhigh | 48 | 25.00 % |
| (lug_boot - big, safety - med ) --> maint - med | 48 | 25.00 % |
| (lug_boot - big, class - acc ) --> maint - high | 40 | 27.78 % |
| (lug_boot - big, class - acc ) --> maint - med | 40 | 27.78 % |
| (lug_boot - big, class - unacc ) --> maint - high | 96 | 26.09 % |
| (lug_boot - big, class - unacc ) --> maint - vhigh | 112 | 30.43 % |
| (lug_boot - big, class - vgood ) --> maint - low | 16 | 40.00 % |
| (lug_boot - big, class - vgood ) --> maint - med | 16 | 40.00 % |
| (lug_boot - big, class - good ) --> maint - low | 16 | 66.67 % |
| (lug_boot - med, safety - high ) --> maint - high | 48 | 25.00 % |
| (lug_boot - med, safety - high ) --> maint - low | 48 | 25.00 % |
| (lug_boot - med, safety - high ) --> maint - vhigh | 48 | 25.00 % |
| (lug_boot - med, safety - high ) --> maint - med | 48 | 25.00 % |
| (lug_boot - med, safety - low ) --> maint - high | 48 | 25.00 % |
| (lug_boot - med, safety - low ) --> maint - low | 48 | 25.00 % |
| (lug_boot - med, safety - low ) --> maint - vhigh | 48 | 25.00 % |
| (lug_boot - med, safety - low ) --> maint - med | 48 | 25.00 % |
| (lug_boot - med, safety - med ) --> maint - high | 48 | 25.00 % |
| (lug_boot - med, safety - med ) --> maint - low | 48 | 25.00 % |
| (lug_boot - med, safety - med ) --> maint - vhigh | 48 | 25.00 % |
| (lug_boot - med, safety - med ) --> maint - med | 48 | 25.00 % |
| (lug_boot - med, class - acc ) --> maint - high | 37 | 27.41 % |
| (lug_boot - med, class - acc ) --> maint - med | 40 | 29.63 % |
| (lug_boot - med, class - unacc ) --> maint - high | 102 | 26.02 % |
| (lug_boot - med, class - unacc ) --> maint - vhigh | 118 | 30.10 % |
| (lug_boot - med, class - good ) --> maint - low | 16 | 66.67 % |
| (safety - high, class - acc ) --> maint - high | 56 | 27.45 % |
| (safety - high, class - acc ) --> maint - med | 56 | 27.45 % |
| (safety - high, class - unacc ) --> maint - high | 75 | 27.08 % |
| (safety - high, class - unacc ) --> maint - vhigh | 98 | 35.38 % |
| (safety - high, class - vgood ) --> maint - low | 26 | 40.00 % |
| (safety - high, class - vgood ) --> maint - med | 26 | 40.00 % |
| (safety - high, class - good ) --> maint - low | 20 | 66.67 % |
| (safety - low, class - unacc ) --> maint - high | 144 | 25.00 % |
| (safety - low, class - unacc ) --> maint - low | 144 | 25.00 % |
| (safety - low, class - unacc ) --> maint - vhigh | 144 | 25.00 % |
| (safety - low, class - unacc ) --> maint - med | 144 | 25.00 % |
| (safety - med, class - acc ) --> maint - high | 49 | 27.22 % |
| (safety - med, class - acc ) --> maint - low | 46 | 25.56 % |
| (safety - med, class - acc ) --> maint - med | 59 | 32.78 % |
| (safety - med, class - unacc ) --> maint - high | 95 | 26.61 % |
| (safety - med, class - unacc ) --> maint - vhigh | 118 | 33.05 % |
| (safety - med, class - good ) --> maint - low | 26 | 66.67 % |

 ## Iteration 3 

### CERTAIN RULES 



 | RULE | SUPPORT | CONFIDENCE |
| -- | -- | -- |
### POSSIBLE RULES


 | RULE | SUPPORT | CONFIDENCE |
| -- | -- | -- |
| (buying - high, doors - 2, class - unacc ) --> maint - vhigh | 27 | 31.03 % |
| (buying - high, doors - 3, class - unacc ) --> maint - vhigh | 27 | 33.33 % |
| (buying - high, doors - 4, class - unacc ) --> maint - vhigh | 27 | 34.62 % |
| (buying - high, doors - 5more, class - unacc ) --> maint - vhigh | 27 | 34.62 % |
| (buying - high, persons - 2, class - unacc ) --> maint - high | 36 | 25.00 % |
| (buying - high, persons - 2, class - unacc ) --> maint - low | 36 | 25.00 % |
| (buying - high, persons - 2, class - unacc ) --> maint - vhigh | 36 | 25.00 % |
| (buying - high, persons - 2, class - unacc ) --> maint - med | 36 | 25.00 % |
| (buying - high, persons - 4, class - acc ) --> maint - high | 18 | 33.33 % |
| (buying - high, persons - 4, class - acc ) --> maint - low | 18 | 33.33 % |
| (buying - high, persons - 4, class - acc ) --> maint - med | 18 | 33.33 % |
| (buying - high, persons - 4, class - unacc ) --> maint - vhigh | 36 | 40.00 % |
| (buying - high, persons - more, class - acc ) --> maint - high | 18 | 33.33 % |
| (buying - high, persons - more, class - acc ) --> maint - low | 18 | 33.33 % |
| (buying - high, persons - more, class - acc ) --> maint - med | 18 | 33.33 % |
| (buying - high, persons - more, class - unacc ) --> maint - vhigh | 36 | 40.00 % |
| (buying - high, lug_boot - small, class - unacc ) --> maint - vhigh | 36 | 29.27 % |
| (buying - high, lug_boot - big, class - acc ) --> maint - high | 16 | 33.33 % |
| (buying - high, lug_boot - big, class - acc ) --> maint - low | 16 | 33.33 % |
| (buying - high, lug_boot - big, class - acc ) --> maint - med | 16 | 33.33 % |
| (buying - high, lug_boot - big, class - unacc ) --> maint - vhigh | 36 | 37.50 % |
| (buying - high, lug_boot - med, class - unacc ) --> maint - vhigh | 36 | 34.29 % |
| (buying - high, safety - high, class - acc ) --> maint - high | 23 | 33.33 % |
| (buying - high, safety - high, class - acc ) --> maint - low | 23 | 33.33 % |
| (buying - high, safety - high, class - acc ) --> maint - med | 23 | 33.33 % |
| (buying - high, safety - high, class - unacc ) --> maint - vhigh | 36 | 48.00 % |
| (buying - high, safety - low, class - unacc ) --> maint - high | 36 | 25.00 % |
| (buying - high, safety - low, class - unacc ) --> maint - low | 36 | 25.00 % |
| (buying - high, safety - low, class - unacc ) --> maint - vhigh | 36 | 25.00 % |
| (buying - high, safety - low, class - unacc ) --> maint - med | 36 | 25.00 % |
| (buying - high, safety - med, class - unacc ) --> maint - vhigh | 36 | 34.29 % |
| (buying - low, doors - 2, class - unacc ) --> maint - vhigh | 20 | 28.17 % |
| (buying - low, doors - 3, class - unacc ) --> maint - vhigh | 18 | 28.57 % |
| (buying - low, doors - 4, class - unacc ) --> maint - vhigh | 17 | 27.42 % |
| (buying - low, doors - 5more, class - unacc ) --> maint - vhigh | 17 | 27.42 % |
| (buying - low, persons - 2, class - unacc ) --> maint - high | 36 | 25.00 % |
| (buying - low, persons - 2, class - unacc ) --> maint - low | 36 | 25.00 % |
| (buying - low, persons - 2, class - unacc ) --> maint - vhigh | 36 | 25.00 % |
| (buying - low, persons - 2, class - unacc ) --> maint - med | 36 | 25.00 % |
| (buying - low, persons - 4, class - acc ) --> maint - high | 18 | 37.50 % |
| (buying - low, persons - 4, class - acc ) --> maint - vhigh | 18 | 37.50 % |
| (buying - low, persons - 4, class - unacc ) --> maint - vhigh | 18 | 33.33 % |
| (buying - low, persons - more, class - acc ) --> maint - high | 15 | 36.59 % |
| (buying - low, persons - more, class - acc ) --> maint - vhigh | 18 | 43.90 % |
| (buying - low, persons - more, class - unacc ) --> maint - vhigh | 18 | 30.00 % |
| (buying - low, lug_boot - small, class - unacc ) --> maint - vhigh | 29 | 30.53 % |
| (buying - low, lug_boot - big, class - acc ) --> maint - vhigh | 16 | 66.67 % |
| (buying - low, lug_boot - big, class - unacc ) --> maint - high | 20 | 25.00 % |
| (buying - low, lug_boot - big, class - unacc ) --> maint - low | 20 | 25.00 % |
| (buying - low, lug_boot - big, class - unacc ) --> maint - vhigh | 20 | 25.00 % |
| (buying - low, lug_boot - big, class - unacc ) --> maint - med | 20 | 25.00 % |
| (buying - low, lug_boot - med, class - unacc ) --> maint - vhigh | 23 | 27.71 % |
| (buying - low, safety - high, class - acc ) --> maint - vhigh | 23 | 69.70 % |
| (buying - low, safety - low, class - unacc ) --> maint - high | 36 | 25.00 % |
| (buying - low, safety - low, class - unacc ) --> maint - low | 36 | 25.00 % |
| (buying - low, safety - low, class - unacc ) --> maint - vhigh | 36 | 25.00 % |
| (buying - low, safety - low, class - unacc ) --> maint - med | 36 | 25.00 % |
| (buying - low, safety - med, class - acc ) --> maint - high | 23 | 41.07 % |
| (buying - low, safety - med, class - unacc ) --> maint - vhigh | 23 | 37.10 % |
| (buying - vhigh, doors - 2, class - unacc ) --> maint - high | 27 | 28.72 % |
| (buying - vhigh, doors - 2, class - unacc ) --> maint - vhigh | 27 | 28.72 % |
| (buying - vhigh, doors - 3, class - unacc ) --> maint - high | 27 | 30.00 % |
| (buying - vhigh, doors - 3, class - unacc ) --> maint - vhigh | 27 | 30.00 % |
| (buying - vhigh, doors - 4, class - unacc ) --> maint - high | 27 | 30.68 % |
| (buying - vhigh, doors - 4, class - unacc ) --> maint - vhigh | 27 | 30.68 % |
| (buying - vhigh, doors - 5more, class - unacc ) --> maint - high | 27 | 30.68 % |
| (buying - vhigh, doors - 5more, class - unacc ) --> maint - vhigh | 27 | 30.68 % |
| (buying - vhigh, persons - 2, class - unacc ) --> maint - high | 36 | 25.00 % |
| (buying - vhigh, persons - 2, class - unacc ) --> maint - low | 36 | 25.00 % |
| (buying - vhigh, persons - 2, class - unacc ) --> maint - vhigh | 36 | 25.00 % |
| (buying - vhigh, persons - 2, class - unacc ) --> maint - med | 36 | 25.00 % |
| (buying - vhigh, persons - 4, class - acc ) --> maint - low | 18 | 50.00 % |
| (buying - vhigh, persons - 4, class - acc ) --> maint - med | 18 | 50.00 % |
| (buying - vhigh, persons - 4, class - unacc ) --> maint - high | 36 | 33.33 % |
| (buying - vhigh, persons - 4, class - unacc ) --> maint - vhigh | 36 | 33.33 % |
| (buying - vhigh, persons - more, class - acc ) --> maint - low | 18 | 50.00 % |
| (buying - vhigh, persons - more, class - acc ) --> maint - med | 18 | 50.00 % |
| (buying - vhigh, persons - more, class - unacc ) --> maint - high | 36 | 33.33 % |
| (buying - vhigh, persons - more, class - unacc ) --> maint - vhigh | 36 | 33.33 % |
| (buying - vhigh, lug_boot - small, class - unacc ) --> maint - high | 36 | 27.69 % |
| (buying - vhigh, lug_boot - small, class - unacc ) --> maint - vhigh | 36 | 27.69 % |
| (buying - vhigh, lug_boot - big, class - acc ) --> maint - low | 16 | 50.00 % |
| (buying - vhigh, lug_boot - big, class - acc ) --> maint - med | 16 | 50.00 % |
| (buying - vhigh, lug_boot - big, class - unacc ) --> maint - high | 36 | 32.14 % |
| (buying - vhigh, lug_boot - big, class - unacc ) --> maint - vhigh | 36 | 32.14 % |
| (buying - vhigh, lug_boot - med, class - unacc ) --> maint - high | 36 | 30.51 % |
| (buying - vhigh, lug_boot - med, class - unacc ) --> maint - vhigh | 36 | 30.51 % |
| (buying - vhigh, safety - high, class - acc ) --> maint - low | 23 | 50.00 % |
| (buying - vhigh, safety - high, class - acc ) --> maint - med | 23 | 50.00 % |
| (buying - vhigh, safety - high, class - unacc ) --> maint - high | 36 | 36.73 % |
| (buying - vhigh, safety - high, class - unacc ) --> maint - vhigh | 36 | 36.73 % |
| (buying - vhigh, safety - low, class - unacc ) --> maint - high | 36 | 25.00 % |
| (buying - vhigh, safety - low, class - unacc ) --> maint - low | 36 | 25.00 % |
| (buying - vhigh, safety - low, class - unacc ) --> maint - vhigh | 36 | 25.00 % |
| (buying - vhigh, safety - low, class - unacc ) --> maint - med | 36 | 25.00 % |
| (buying - vhigh, safety - med, class - unacc ) --> maint - high | 36 | 30.51 % |
| (buying - vhigh, safety - med, class - unacc ) --> maint - vhigh | 36 | 30.51 % |
| (buying - med, doors - 2, class - unacc ) --> maint - high | 20 | 27.03 % |
| (buying - med, doors - 2, class - unacc ) --> maint - vhigh | 20 | 27.03 % |
| (buying - med, doors - 3, class - unacc ) --> maint - high | 18 | 27.27 % |
| (buying - med, doors - 3, class - unacc ) --> maint - vhigh | 18 | 27.27 % |
| (buying - med, doors - 4, class - unacc ) --> maint - high | 17 | 26.56 % |
| (buying - med, doors - 4, class - unacc ) --> maint - vhigh | 17 | 26.56 % |
| (buying - med, doors - 5more, class - unacc ) --> maint - high | 17 | 26.56 % |
| (buying - med, doors - 5more, class - unacc ) --> maint - vhigh | 17 | 26.56 % |
| (buying - med, persons - 2, class - unacc ) --> maint - high | 36 | 25.00 % |
| (buying - med, persons - 2, class - unacc ) --> maint - low | 36 | 25.00 % |
| (buying - med, persons - 2, class - unacc ) --> maint - vhigh | 36 | 25.00 % |
| (buying - med, persons - 2, class - unacc ) --> maint - med | 36 | 25.00 % |
| (buying - med, persons - 4, class - acc ) --> maint - high | 18 | 30.00 % |
| (buying - med, persons - 4, class - acc ) --> maint - vhigh | 18 | 30.00 % |
| (buying - med, persons - 4, class - acc ) --> maint - med | 18 | 30.00 % |
| (buying - med, persons - 4, class - unacc ) --> maint - high | 18 | 30.00 % |
| (buying - med, persons - 4, class - unacc ) --> maint - vhigh | 18 | 30.00 % |
| (buying - med, persons - more, class - acc ) --> maint - high | 18 | 32.73 % |
| (buying - med, persons - more, class - acc ) --> maint - vhigh | 18 | 32.73 % |
| (buying - med, persons - more, class - acc ) --> maint - med | 15 | 27.27 % |
| (buying - med, persons - more, class - unacc ) --> maint - high | 18 | 28.13 % |
| (buying - med, persons - more, class - unacc ) --> maint - vhigh | 18 | 28.13 % |
| (buying - med, lug_boot - small, class - unacc ) --> maint - high | 29 | 28.43 % |
| (buying - med, lug_boot - small, class - unacc ) --> maint - vhigh | 29 | 28.43 % |
| (buying - med, lug_boot - big, class - acc ) --> maint - high | 16 | 40.00 % |
| (buying - med, lug_boot - big, class - acc ) --> maint - vhigh | 16 | 40.00 % |
| (buying - med, lug_boot - big, class - unacc ) --> maint - high | 20 | 25.00 % |
| (buying - med, lug_boot - big, class - unacc ) --> maint - low | 20 | 25.00 % |
| (buying - med, lug_boot - big, class - unacc ) --> maint - vhigh | 20 | 25.00 % |
| (buying - med, lug_boot - big, class - unacc ) --> maint - med | 20 | 25.00 % |
| (buying - med, lug_boot - med, class - unacc ) --> maint - high | 23 | 26.74 % |
| (buying - med, lug_boot - med, class - unacc ) --> maint - vhigh | 23 | 26.74 % |
| (buying - med, safety - high, class - acc ) --> maint - high | 23 | 41.07 % |
| (buying - med, safety - high, class - acc ) --> maint - vhigh | 23 | 41.07 % |
| (buying - med, safety - low, class - unacc ) --> maint - high | 36 | 25.00 % |
| (buying - med, safety - low, class - unacc ) --> maint - low | 36 | 25.00 % |
| (buying - med, safety - low, class - unacc ) --> maint - vhigh | 36 | 25.00 % |
| (buying - med, safety - low, class - unacc ) --> maint - med | 36 | 25.00 % |
| (buying - med, safety - med, class - acc ) --> maint - med | 23 | 38.98 % |
| (buying - med, safety - med, class - unacc ) --> maint - high | 23 | 31.94 % |
| (buying - med, safety - med, class - unacc ) --> maint - vhigh | 23 | 31.94 % |
| (doors - 2, persons - 2, class - unacc ) --> maint - high | 36 | 25.00 % |
| (doors - 2, persons - 2, class - unacc ) --> maint - low | 36 | 25.00 % |
| (doors - 2, persons - 2, class - unacc ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 2, persons - 2, class - unacc ) --> maint - med | 36 | 25.00 % |
| (doors - 2, persons - 4, class - acc ) --> maint - med | 15 | 31.25 % |
| (doors - 2, persons - 4, class - unacc ) --> maint - high | 22 | 26.83 % |
| (doors - 2, persons - 4, class - unacc ) --> maint - vhigh | 28 | 34.15 % |
| (doors - 2, persons - more, class - unacc ) --> maint - high | 26 | 26.00 % |
| (doors - 2, persons - more, class - unacc ) --> maint - vhigh | 30 | 30.00 % |
| (doors - 2, lug_boot - small, class - unacc ) --> maint - high | 32 | 25.40 % |
| (doors - 2, lug_boot - small, class - unacc ) --> maint - vhigh | 34 | 26.98 % |
| (doors - 2, lug_boot - big, class - unacc ) --> maint - high | 24 | 26.09 % |
| (doors - 2, lug_boot - big, class - unacc ) --> maint - vhigh | 28 | 30.43 % |
| (doors - 2, lug_boot - med, class - unacc ) --> maint - high | 28 | 25.93 % |
| (doors - 2, lug_boot - med, class - unacc ) --> maint - vhigh | 32 | 29.63 % |
| (doors - 2, safety - high, class - unacc ) --> maint - high | 21 | 26.58 % |
| (doors - 2, safety - high, class - unacc ) --> maint - vhigh | 26 | 32.91 % |
| (doors - 2, safety - low, class - unacc ) --> maint - high | 36 | 25.00 % |
| (doors - 2, safety - low, class - unacc ) --> maint - low | 36 | 25.00 % |
| (doors - 2, safety - low, class - unacc ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 2, safety - low, class - unacc ) --> maint - med | 36 | 25.00 % |
| (doors - 2, safety - med, class - unacc ) --> maint - high | 27 | 26.21 % |
| (doors - 2, safety - med, class - unacc ) --> maint - vhigh | 32 | 31.07 % |
| (doors - 3, persons - 2, class - unacc ) --> maint - high | 36 | 25.00 % |
| (doors - 3, persons - 2, class - unacc ) --> maint - low | 36 | 25.00 % |
| (doors - 3, persons - 2, class - unacc ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 3, persons - 2, class - unacc ) --> maint - med | 36 | 25.00 % |
| (doors - 3, persons - 4, class - acc ) --> maint - med | 15 | 31.25 % |
| (doors - 3, persons - 4, class - unacc ) --> maint - high | 22 | 26.83 % |
| (doors - 3, persons - 4, class - unacc ) --> maint - vhigh | 28 | 34.15 % |
| (doors - 3, persons - more, class - acc ) --> maint - med | 15 | 29.41 % |
| (doors - 3, persons - more, class - unacc ) --> maint - high | 20 | 27.03 % |
| (doors - 3, persons - more, class - unacc ) --> maint - vhigh | 26 | 35.14 % |
| (doors - 3, lug_boot - small, class - unacc ) --> maint - high | 28 | 25.93 % |
| (doors - 3, lug_boot - small, class - unacc ) --> maint - vhigh | 32 | 29.63 % |
| (doors - 3, lug_boot - big, class - unacc ) --> maint - high | 24 | 26.09 % |
| (doors - 3, lug_boot - big, class - unacc ) --> maint - vhigh | 28 | 30.43 % |
| (doors - 3, lug_boot - med, class - unacc ) --> maint - high | 26 | 26.00 % |
| (doors - 3, lug_boot - med, class - unacc ) --> maint - vhigh | 30 | 30.00 % |
| (doors - 3, safety - high, class - acc ) --> maint - high | 15 | 27.78 % |
| (doors - 3, safety - high, class - acc ) --> maint - med | 15 | 27.78 % |
| (doors - 3, safety - high, class - unacc ) --> maint - high | 18 | 27.27 % |
| (doors - 3, safety - high, class - unacc ) --> maint - vhigh | 24 | 36.36 % |
| (doors - 3, safety - low, class - unacc ) --> maint - high | 36 | 25.00 % |
| (doors - 3, safety - low, class - unacc ) --> maint - low | 36 | 25.00 % |
| (doors - 3, safety - low, class - unacc ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 3, safety - low, class - unacc ) --> maint - med | 36 | 25.00 % |
| (doors - 3, safety - med, class - acc ) --> maint - med | 15 | 33.33 % |
| (doors - 3, safety - med, class - unacc ) --> maint - high | 24 | 26.67 % |
| (doors - 3, safety - med, class - unacc ) --> maint - vhigh | 30 | 33.33 % |
| (doors - 4, persons - 2, class - unacc ) --> maint - high | 36 | 25.00 % |
| (doors - 4, persons - 2, class - unacc ) --> maint - low | 36 | 25.00 % |
| (doors - 4, persons - 2, class - unacc ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 4, persons - 2, class - unacc ) --> maint - med | 36 | 25.00 % |
| (doors - 4, persons - 4, class - acc ) --> maint - med | 15 | 29.41 % |
| (doors - 4, persons - 4, class - unacc ) --> maint - high | 20 | 27.03 % |
| (doors - 4, persons - 4, class - unacc ) --> maint - vhigh | 26 | 35.14 % |
| (doors - 4, persons - more, class - acc ) --> maint - med | 15 | 29.41 % |
| (doors - 4, persons - more, class - unacc ) --> maint - high | 20 | 27.03 % |
| (doors - 4, persons - more, class - unacc ) --> maint - vhigh | 26 | 35.14 % |
| (doors - 4, lug_boot - small, class - unacc ) --> maint - high | 28 | 25.93 % |
| (doors - 4, lug_boot - small, class - unacc ) --> maint - vhigh | 32 | 29.63 % |
| (doors - 4, lug_boot - big, class - unacc ) --> maint - high | 24 | 26.09 % |
| (doors - 4, lug_boot - big, class - unacc ) --> maint - vhigh | 28 | 30.43 % |
| (doors - 4, lug_boot - med, class - unacc ) --> maint - high | 24 | 26.09 % |
| (doors - 4, lug_boot - med, class - unacc ) --> maint - vhigh | 28 | 30.43 % |
| (doors - 4, safety - high, class - unacc ) --> maint - high | 18 | 27.27 % |
| (doors - 4, safety - high, class - unacc ) --> maint - vhigh | 24 | 36.36 % |
| (doors - 4, safety - low, class - unacc ) --> maint - high | 36 | 25.00 % |
| (doors - 4, safety - low, class - unacc ) --> maint - low | 36 | 25.00 % |
| (doors - 4, safety - low, class - unacc ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 4, safety - low, class - unacc ) --> maint - med | 36 | 25.00 % |
| (doors - 4, safety - med, class - acc ) --> maint - med | 16 | 32.00 % |
| (doors - 4, safety - med, class - unacc ) --> maint - high | 22 | 26.83 % |
| (doors - 4, safety - med, class - unacc ) --> maint - vhigh | 28 | 34.15 % |
| (doors - 5more, persons - 2, class - unacc ) --> maint - high | 36 | 25.00 % |
| (doors - 5more, persons - 2, class - unacc ) --> maint - low | 36 | 25.00 % |
| (doors - 5more, persons - 2, class - unacc ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 5more, persons - 2, class - unacc ) --> maint - med | 36 | 25.00 % |
| (doors - 5more, persons - 4, class - acc ) --> maint - med | 15 | 29.41 % |
| (doors - 5more, persons - 4, class - unacc ) --> maint - high | 20 | 27.03 % |
| (doors - 5more, persons - 4, class - unacc ) --> maint - vhigh | 26 | 35.14 % |
| (doors - 5more, persons - more, class - acc ) --> maint - med | 15 | 29.41 % |
| (doors - 5more, persons - more, class - unacc ) --> maint - high | 20 | 27.03 % |
| (doors - 5more, persons - more, class - unacc ) --> maint - vhigh | 26 | 35.14 % |
| (doors - 5more, lug_boot - small, class - unacc ) --> maint - high | 28 | 25.93 % |
| (doors - 5more, lug_boot - small, class - unacc ) --> maint - vhigh | 32 | 29.63 % |
| (doors - 5more, lug_boot - big, class - unacc ) --> maint - high | 24 | 26.09 % |
| (doors - 5more, lug_boot - big, class - unacc ) --> maint - vhigh | 28 | 30.43 % |
| (doors - 5more, lug_boot - med, class - unacc ) --> maint - high | 24 | 26.09 % |
| (doors - 5more, lug_boot - med, class - unacc ) --> maint - vhigh | 28 | 30.43 % |
| (doors - 5more, safety - high, class - unacc ) --> maint - high | 18 | 27.27 % |
| (doors - 5more, safety - high, class - unacc ) --> maint - vhigh | 24 | 36.36 % |
| (doors - 5more, safety - low, class - unacc ) --> maint - high | 36 | 25.00 % |
| (doors - 5more, safety - low, class - unacc ) --> maint - low | 36 | 25.00 % |
| (doors - 5more, safety - low, class - unacc ) --> maint - vhigh | 36 | 25.00 % |
| (doors - 5more, safety - low, class - unacc ) --> maint - med | 36 | 25.00 % |
| (doors - 5more, safety - med, class - acc ) --> maint - med | 16 | 32.00 % |
| (doors - 5more, safety - med, class - unacc ) --> maint - high | 22 | 26.83 % |
| (doors - 5more, safety - med, class - unacc ) --> maint - vhigh | 28 | 34.15 % |
| (persons - 2, lug_boot - small, safety - high ) --> maint - high | 16 | 25.00 % |
| (persons - 2, lug_boot - small, safety - high ) --> maint - low | 16 | 25.00 % |
| (persons - 2, lug_boot - small, safety - high ) --> maint - vhigh | 16 | 25.00 % |
| (persons - 2, lug_boot - small, safety - high ) --> maint - med | 16 | 25.00 % |
| (persons - 2, lug_boot - small, safety - low ) --> maint - high | 16 | 25.00 % |
| (persons - 2, lug_boot - small, safety - low ) --> maint - low | 16 | 25.00 % |
| (persons - 2, lug_boot - small, safety - low ) --> maint - vhigh | 16 | 25.00 % |
| (persons - 2, lug_boot - small, safety - low ) --> maint - med | 16 | 25.00 % |
| (persons - 2, lug_boot - small, safety - med ) --> maint - high | 16 | 25.00 % |
| (persons - 2, lug_boot - small, safety - med ) --> maint - low | 16 | 25.00 % |
| (persons - 2, lug_boot - small, safety - med ) --> maint - vhigh | 16 | 25.00 % |
| (persons - 2, lug_boot - small, safety - med ) --> maint - med | 16 | 25.00 % |
| (persons - 2, lug_boot - small, class - unacc ) --> maint - high | 48 | 25.00 % |
| (persons - 2, lug_boot - small, class - unacc ) --> maint - low | 48 | 25.00 % |
| (persons - 2, lug_boot - small, class - unacc ) --> maint - vhigh | 48 | 25.00 % |
| (persons - 2, lug_boot - small, class - unacc ) --> maint - med | 48 | 25.00 % |
| (persons - 2, lug_boot - big, safety - high ) --> maint - high | 16 | 25.00 % |
| (persons - 2, lug_boot - big, safety - high ) --> maint - low | 16 | 25.00 % |
| (persons - 2, lug_boot - big, safety - high ) --> maint - vhigh | 16 | 25.00 % |
| (persons - 2, lug_boot - big, safety - high ) --> maint - med | 16 | 25.00 % |
| (persons - 2, lug_boot - big, safety - low ) --> maint - high | 16 | 25.00 % |
| (persons - 2, lug_boot - big, safety - low ) --> maint - low | 16 | 25.00 % |
| (persons - 2, lug_boot - big, safety - low ) --> maint - vhigh | 16 | 25.00 % |
| (persons - 2, lug_boot - big, safety - low ) --> maint - med | 16 | 25.00 % |
| (persons - 2, lug_boot - big, safety - med ) --> maint - high | 16 | 25.00 % |
| (persons - 2, lug_boot - big, safety - med ) --> maint - low | 16 | 25.00 % |
| (persons - 2, lug_boot - big, safety - med ) --> maint - vhigh | 16 | 25.00 % |
| (persons - 2, lug_boot - big, safety - med ) --> maint - med | 16 | 25.00 % |
| (persons - 2, lug_boot - big, class - unacc ) --> maint - high | 48 | 25.00 % |
| (persons - 2, lug_boot - big, class - unacc ) --> maint - low | 48 | 25.00 % |
| (persons - 2, lug_boot - big, class - unacc ) --> maint - vhigh | 48 | 25.00 % |
| (persons - 2, lug_boot - big, class - unacc ) --> maint - med | 48 | 25.00 % |
| (persons - 2, lug_boot - med, safety - high ) --> maint - high | 16 | 25.00 % |
| (persons - 2, lug_boot - med, safety - high ) --> maint - low | 16 | 25.00 % |
| (persons - 2, lug_boot - med, safety - high ) --> maint - vhigh | 16 | 25.00 % |
| (persons - 2, lug_boot - med, safety - high ) --> maint - med | 16 | 25.00 % |
| (persons - 2, lug_boot - med, safety - low ) --> maint - high | 16 | 25.00 % |
| (persons - 2, lug_boot - med, safety - low ) --> maint - low | 16 | 25.00 % |
| (persons - 2, lug_boot - med, safety - low ) --> maint - vhigh | 16 | 25.00 % |
| (persons - 2, lug_boot - med, safety - low ) --> maint - med | 16 | 25.00 % |
| (persons - 2, lug_boot - med, safety - med ) --> maint - high | 16 | 25.00 % |
| (persons - 2, lug_boot - med, safety - med ) --> maint - low | 16 | 25.00 % |
| (persons - 2, lug_boot - med, safety - med ) --> maint - vhigh | 16 | 25.00 % |
| (persons - 2, lug_boot - med, safety - med ) --> maint - med | 16 | 25.00 % |
| (persons - 2, lug_boot - med, class - unacc ) --> maint - high | 48 | 25.00 % |
| (persons - 2, lug_boot - med, class - unacc ) --> maint - low | 48 | 25.00 % |
| (persons - 2, lug_boot - med, class - unacc ) --> maint - vhigh | 48 | 25.00 % |
| (persons - 2, lug_boot - med, class - unacc ) --> maint - med | 48 | 25.00 % |
| (persons - 2, safety - high, class - unacc ) --> maint - high | 48 | 25.00 % |
| (persons - 2, safety - high, class - unacc ) --> maint - low | 48 | 25.00 % |
| (persons - 2, safety - high, class - unacc ) --> maint - vhigh | 48 | 25.00 % |
| (persons - 2, safety - high, class - unacc ) --> maint - med | 48 | 25.00 % |
| (persons - 2, safety - low, class - unacc ) --> maint - high | 48 | 25.00 % |
| (persons - 2, safety - low, class - unacc ) --> maint - low | 48 | 25.00 % |
| (persons - 2, safety - low, class - unacc ) --> maint - vhigh | 48 | 25.00 % |
| (persons - 2, safety - low, class - unacc ) --> maint - med | 48 | 25.00 % |
| (persons - 2, safety - med, class - unacc ) --> maint - high | 48 | 25.00 % |
| (persons - 2, safety - med, class - unacc ) --> maint - low | 48 | 25.00 % |
| (persons - 2, safety - med, class - unacc ) --> maint - vhigh | 48 | 25.00 % |
| (persons - 2, safety - med, class - unacc ) --> maint - med | 48 | 25.00 % |
| (persons - 4, lug_boot - small, safety - high ) --> maint - high | 16 | 25.00 % |
| (persons - 4, lug_boot - small, safety - high ) --> maint - low | 16 | 25.00 % |
| (persons - 4, lug_boot - small, safety - high ) --> maint - vhigh | 16 | 25.00 % |
| (persons - 4, lug_boot - small, safety - high ) --> maint - med | 16 | 25.00 % |
| (persons - 4, lug_boot - small, safety - low ) --> maint - high | 16 | 25.00 % |
| (persons - 4, lug_boot - small, safety - low ) --> maint - low | 16 | 25.00 % |
| (persons - 4, lug_boot - small, safety - low ) --> maint - vhigh | 16 | 25.00 % |
| (persons - 4, lug_boot - small, safety - low ) --> maint - med | 16 | 25.00 % |
| (persons - 4, lug_boot - small, safety - med ) --> maint - high | 16 | 25.00 % |
| (persons - 4, lug_boot - small, safety - med ) --> maint - low | 16 | 25.00 % |
| (persons - 4, lug_boot - small, safety - med ) --> maint - vhigh | 16 | 25.00 % |
| (persons - 4, lug_boot - small, safety - med ) --> maint - med | 16 | 25.00 % |
| (persons - 4, lug_boot - small, class - acc ) --> maint - high | 16 | 26.67 % |
| (persons - 4, lug_boot - small, class - acc ) --> maint - low | 16 | 26.67 % |
| (persons - 4, lug_boot - small, class - acc ) --> maint - med | 20 | 33.33 % |
| (persons - 4, lug_boot - small, class - unacc ) --> maint - high | 32 | 26.67 % |
| (persons - 4, lug_boot - small, class - unacc ) --> maint - vhigh | 40 | 33.33 % |
| (persons - 4, lug_boot - big, safety - high ) --> maint - high | 16 | 25.00 % |
| (persons - 4, lug_boot - big, safety - high ) --> maint - low | 16 | 25.00 % |
| (persons - 4, lug_boot - big, safety - high ) --> maint - vhigh | 16 | 25.00 % |
| (persons - 4, lug_boot - big, safety - high ) --> maint - med | 16 | 25.00 % |
| (persons - 4, lug_boot - big, safety - low ) --> maint - high | 16 | 25.00 % |
| (persons - 4, lug_boot - big, safety - low ) --> maint - low | 16 | 25.00 % |
| (persons - 4, lug_boot - big, safety - low ) --> maint - vhigh | 16 | 25.00 % |
| (persons - 4, lug_boot - big, safety - low ) --> maint - med | 16 | 25.00 % |
| (persons - 4, lug_boot - big, safety - med ) --> maint - high | 16 | 25.00 % |
| (persons - 4, lug_boot - big, safety - med ) --> maint - low | 16 | 25.00 % |
| (persons - 4, lug_boot - big, safety - med ) --> maint - vhigh | 16 | 25.00 % |
| (persons - 4, lug_boot - big, safety - med ) --> maint - med | 16 | 25.00 % |
| (persons - 4, lug_boot - big, class - acc ) --> maint - high | 20 | 27.78 % |
| (persons - 4, lug_boot - big, class - acc ) --> maint - med | 20 | 27.78 % |
| (persons - 4, lug_boot - big, class - unacc ) --> maint - high | 24 | 27.27 % |
| (persons - 4, lug_boot - big, class - unacc ) --> maint - vhigh | 32 | 36.36 % |
| (persons - 4, lug_boot - med, safety - high ) --> maint - high | 16 | 25.00 % |
| (persons - 4, lug_boot - med, safety - high ) --> maint - low | 16 | 25.00 % |
| (persons - 4, lug_boot - med, safety - high ) --> maint - vhigh | 16 | 25.00 % |
| (persons - 4, lug_boot - med, safety - high ) --> maint - med | 16 | 25.00 % |
| (persons - 4, lug_boot - med, safety - low ) --> maint - high | 16 | 25.00 % |
| (persons - 4, lug_boot - med, safety - low ) --> maint - low | 16 | 25.00 % |
| (persons - 4, lug_boot - med, safety - low ) --> maint - vhigh | 16 | 25.00 % |
| (persons - 4, lug_boot - med, safety - low ) --> maint - med | 16 | 25.00 % |
| (persons - 4, lug_boot - med, safety - med ) --> maint - high | 16 | 25.00 % |
| (persons - 4, lug_boot - med, safety - med ) --> maint - low | 16 | 25.00 % |
| (persons - 4, lug_boot - med, safety - med ) --> maint - vhigh | 16 | 25.00 % |
| (persons - 4, lug_boot - med, safety - med ) --> maint - med | 16 | 25.00 % |
| (persons - 4, lug_boot - med, class - acc ) --> maint - high | 18 | 27.27 % |
| (persons - 4, lug_boot - med, class - acc ) --> maint - med | 20 | 30.30 % |
| (persons - 4, lug_boot - med, class - unacc ) --> maint - high | 28 | 26.92 % |
| (persons - 4, lug_boot - med, class - unacc ) --> maint - vhigh | 36 | 34.62 % |
| (persons - 4, safety - high, class - acc ) --> maint - high | 30 | 27.78 % |
| (persons - 4, safety - high, class - acc ) --> maint - med | 30 | 27.78 % |
| (persons - 4, safety - high, class - unacc ) --> maint - vhigh | 24 | 66.67 % |
| (persons - 4, safety - low, class - unacc ) --> maint - high | 48 | 25.00 % |
| (persons - 4, safety - low, class - unacc ) --> maint - low | 48 | 25.00 % |
| (persons - 4, safety - low, class - unacc ) --> maint - vhigh | 48 | 25.00 % |
| (persons - 4, safety - low, class - unacc ) --> maint - med | 48 | 25.00 % |
| (persons - 4, safety - med, class - acc ) --> maint - high | 24 | 26.67 % |
| (persons - 4, safety - med, class - acc ) --> maint - low | 24 | 26.67 % |
| (persons - 4, safety - med, class - acc ) --> maint - med | 30 | 33.33 % |
| (persons - 4, safety - med, class - unacc ) --> maint - high | 24 | 28.57 % |
| (persons - 4, safety - med, class - unacc ) --> maint - vhigh | 36 | 42.86 % |
| (persons - more, lug_boot - small, safety - high ) --> maint - high | 16 | 25.00 % |
| (persons - more, lug_boot - small, safety - high ) --> maint - low | 16 | 25.00 % |
| (persons - more, lug_boot - small, safety - high ) --> maint - vhigh | 16 | 25.00 % |
| (persons - more, lug_boot - small, safety - high ) --> maint - med | 16 | 25.00 % |
| (persons - more, lug_boot - small, safety - low ) --> maint - high | 16 | 25.00 % |
| (persons - more, lug_boot - small, safety - low ) --> maint - low | 16 | 25.00 % |
| (persons - more, lug_boot - small, safety - low ) --> maint - vhigh | 16 | 25.00 % |
| (persons - more, lug_boot - small, safety - low ) --> maint - med | 16 | 25.00 % |
| (persons - more, lug_boot - small, safety - med ) --> maint - high | 16 | 25.00 % |
| (persons - more, lug_boot - small, safety - med ) --> maint - low | 16 | 25.00 % |
| (persons - more, lug_boot - small, safety - med ) --> maint - vhigh | 16 | 25.00 % |
| (persons - more, lug_boot - small, safety - med ) --> maint - med | 16 | 25.00 % |
| (persons - more, lug_boot - small, class - acc ) --> maint - med | 15 | 33.33 % |
| (persons - more, lug_boot - small, class - unacc ) --> maint - high | 36 | 26.09 % |
| (persons - more, lug_boot - small, class - unacc ) --> maint - vhigh | 42 | 30.43 % |
| (persons - more, lug_boot - big, safety - high ) --> maint - high | 16 | 25.00 % |
| (persons - more, lug_boot - big, safety - high ) --> maint - low | 16 | 25.00 % |
| (persons - more, lug_boot - big, safety - high ) --> maint - vhigh | 16 | 25.00 % |
| (persons - more, lug_boot - big, safety - high ) --> maint - med | 16 | 25.00 % |
| (persons - more, lug_boot - big, safety - low ) --> maint - high | 16 | 25.00 % |
| (persons - more, lug_boot - big, safety - low ) --> maint - low | 16 | 25.00 % |
| (persons - more, lug_boot - big, safety - low ) --> maint - vhigh | 16 | 25.00 % |
| (persons - more, lug_boot - big, safety - low ) --> maint - med | 16 | 25.00 % |
| (persons - more, lug_boot - big, safety - med ) --> maint - high | 16 | 25.00 % |
| (persons - more, lug_boot - big, safety - med ) --> maint - low | 16 | 25.00 % |
| (persons - more, lug_boot - big, safety - med ) --> maint - vhigh | 16 | 25.00 % |
| (persons - more, lug_boot - big, safety - med ) --> maint - med | 16 | 25.00 % |
| (persons - more, lug_boot - big, class - acc ) --> maint - high | 20 | 27.78 % |
| (persons - more, lug_boot - big, class - acc ) --> maint - med | 20 | 27.78 % |
| (persons - more, lug_boot - big, class - unacc ) --> maint - high | 24 | 27.27 % |
| (persons - more, lug_boot - big, class - unacc ) --> maint - vhigh | 32 | 36.36 % |
| (persons - more, lug_boot - med, safety - high ) --> maint - high | 16 | 25.00 % |
| (persons - more, lug_boot - med, safety - high ) --> maint - low | 16 | 25.00 % |
| (persons - more, lug_boot - med, safety - high ) --> maint - vhigh | 16 | 25.00 % |
| (persons - more, lug_boot - med, safety - high ) --> maint - med | 16 | 25.00 % |
| (persons - more, lug_boot - med, safety - low ) --> maint - high | 16 | 25.00 % |
| (persons - more, lug_boot - med, safety - low ) --> maint - low | 16 | 25.00 % |
| (persons - more, lug_boot - med, safety - low ) --> maint - vhigh | 16 | 25.00 % |
| (persons - more, lug_boot - med, safety - low ) --> maint - med | 16 | 25.00 % |
| (persons - more, lug_boot - med, safety - med ) --> maint - high | 16 | 25.00 % |
| (persons - more, lug_boot - med, safety - med ) --> maint - low | 16 | 25.00 % |
| (persons - more, lug_boot - med, safety - med ) --> maint - vhigh | 16 | 25.00 % |
| (persons - more, lug_boot - med, safety - med ) --> maint - med | 16 | 25.00 % |
| (persons - more, lug_boot - med, class - acc ) --> maint - high | 19 | 27.54 % |
| (persons - more, lug_boot - med, class - acc ) --> maint - med | 20 | 28.99 % |
| (persons - more, lug_boot - med, class - unacc ) --> maint - high | 26 | 27.08 % |
| (persons - more, lug_boot - med, class - unacc ) --> maint - vhigh | 34 | 35.42 % |
| (persons - more, safety - high, class - acc ) --> maint - high | 26 | 27.08 % |
| (persons - more, safety - high, class - acc ) --> maint - med | 26 | 27.08 % |
| (persons - more, safety - high, class - unacc ) --> maint - high | 15 | 30.61 % |
| (persons - more, safety - high, class - unacc ) --> maint - vhigh | 26 | 53.06 % |
| (persons - more, safety - low, class - unacc ) --> maint - high | 48 | 25.00 % |
| (persons - more, safety - low, class - unacc ) --> maint - low | 48 | 25.00 % |
| (persons - more, safety - low, class - unacc ) --> maint - vhigh | 48 | 25.00 % |
| (persons - more, safety - low, class - unacc ) --> maint - med | 48 | 25.00 % |
| (persons - more, safety - med, class - acc ) --> maint - high | 25 | 27.78 % |
| (persons - more, safety - med, class - acc ) --> maint - med | 29 | 32.22 % |
| (persons - more, safety - med, class - unacc ) --> maint - high | 23 | 28.40 % |
| (persons - more, safety - med, class - unacc ) --> maint - vhigh | 34 | 41.98 % |
| (lug_boot - small, safety - high, class - acc ) --> maint - high | 21 | 30.00 % |
| (lug_boot - small, safety - high, class - acc ) --> maint - med | 21 | 30.00 % |
| (lug_boot - small, safety - high, class - unacc ) --> maint - high | 27 | 26.73 % |
| (lug_boot - small, safety - high, class - unacc ) --> maint - vhigh | 34 | 33.66 % |
| (lug_boot - small, safety - low, class - unacc ) --> maint - high | 48 | 25.00 % |
| (lug_boot - small, safety - low, class - unacc ) --> maint - low | 48 | 25.00 % |
| (lug_boot - small, safety - low, class - unacc ) --> maint - vhigh | 48 | 25.00 % |
| (lug_boot - small, safety - low, class - unacc ) --> maint - med | 48 | 25.00 % |
| (lug_boot - small, safety - med, class - unacc ) --> maint - high | 41 | 26.11 % |
| (lug_boot - small, safety - med, class - unacc ) --> maint - vhigh | 48 | 30.57 % |
| (lug_boot - big, safety - high, class - acc ) --> maint - high | 16 | 25.00 % |
| (lug_boot - big, safety - high, class - acc ) --> maint - low | 16 | 25.00 % |
| (lug_boot - big, safety - high, class - acc ) --> maint - vhigh | 16 | 25.00 % |
| (lug_boot - big, safety - high, class - acc ) --> maint - med | 16 | 25.00 % |
| (lug_boot - big, safety - high, class - unacc ) --> maint - high | 24 | 27.27 % |
| (lug_boot - big, safety - high, class - unacc ) --> maint - vhigh | 32 | 36.36 % |
| (lug_boot - big, safety - high, class - vgood ) --> maint - low | 16 | 40.00 % |
| (lug_boot - big, safety - high, class - vgood ) --> maint - med | 16 | 40.00 % |
| (lug_boot - big, safety - low, class - unacc ) --> maint - high | 48 | 25.00 % |
| (lug_boot - big, safety - low, class - unacc ) --> maint - low | 48 | 25.00 % |
| (lug_boot - big, safety - low, class - unacc ) --> maint - vhigh | 48 | 25.00 % |
| (lug_boot - big, safety - low, class - unacc ) --> maint - med | 48 | 25.00 % |
| (lug_boot - big, safety - med, class - acc ) --> maint - high | 24 | 30.00 % |
| (lug_boot - big, safety - med, class - acc ) --> maint - med | 24 | 30.00 % |
| (lug_boot - big, safety - med, class - unacc ) --> maint - high | 24 | 27.27 % |
| (lug_boot - big, safety - med, class - unacc ) --> maint - vhigh | 32 | 36.36 % |
| (lug_boot - big, safety - med, class - good ) --> maint - low | 16 | 66.67 % |
| (lug_boot - med, safety - high, class - acc ) --> maint - high | 19 | 27.14 % |
| (lug_boot - med, safety - high, class - acc ) --> maint - med | 19 | 27.14 % |
| (lug_boot - med, safety - high, class - unacc ) --> maint - high | 24 | 27.27 % |
| (lug_boot - med, safety - high, class - unacc ) --> maint - vhigh | 32 | 36.36 % |
| (lug_boot - med, safety - low, class - unacc ) --> maint - high | 48 | 25.00 % |
| (lug_boot - med, safety - low, class - unacc ) --> maint - low | 48 | 25.00 % |
| (lug_boot - med, safety - low, class - unacc ) --> maint - vhigh | 48 | 25.00 % |
| (lug_boot - med, safety - low, class - unacc ) --> maint - med | 48 | 25.00 % |
| (lug_boot - med, safety - med, class - acc ) --> maint - high | 18 | 27.69 % |
| (lug_boot - med, safety - med, class - acc ) --> maint - med | 21 | 32.31 % |
| (lug_boot - med, safety - med, class - unacc ) --> maint - high | 30 | 26.79 % |
| (lug_boot - med, safety - med, class - unacc ) --> maint - vhigh | 38 | 33.93 % |

 ## Iteration 4 

### CERTAIN RULES 



 | RULE | SUPPORT | CONFIDENCE |
| -- | -- | -- |
### POSSIBLE RULES


 | RULE | SUPPORT | CONFIDENCE |
| -- | -- | -- |
| (persons - 2, lug_boot - small, safety - high, class - unacc ) --> maint - high | 16 | 25.00 % |
| (persons - 2, lug_boot - small, safety - high, class - unacc ) --> maint - low | 16 | 25.00 % |
| (persons - 2, lug_boot - small, safety - high, class - unacc ) --> maint - vhigh | 16 | 25.00 % |
| (persons - 2, lug_boot - small, safety - high, class - unacc ) --> maint - med | 16 | 25.00 % |
| (persons - 2, lug_boot - small, safety - low, class - unacc ) --> maint - high | 16 | 25.00 % |
| (persons - 2, lug_boot - small, safety - low, class - unacc ) --> maint - low | 16 | 25.00 % |
| (persons - 2, lug_boot - small, safety - low, class - unacc ) --> maint - vhigh | 16 | 25.00 % |
| (persons - 2, lug_boot - small, safety - low, class - unacc ) --> maint - med | 16 | 25.00 % |
| (persons - 2, lug_boot - small, safety - med, class - unacc ) --> maint - high | 16 | 25.00 % |
| (persons - 2, lug_boot - small, safety - med, class - unacc ) --> maint - low | 16 | 25.00 % |
| (persons - 2, lug_boot - small, safety - med, class - unacc ) --> maint - vhigh | 16 | 25.00 % |
| (persons - 2, lug_boot - small, safety - med, class - unacc ) --> maint - med | 16 | 25.00 % |
| (persons - 2, lug_boot - big, safety - high, class - unacc ) --> maint - high | 16 | 25.00 % |
| (persons - 2, lug_boot - big, safety - high, class - unacc ) --> maint - low | 16 | 25.00 % |
| (persons - 2, lug_boot - big, safety - high, class - unacc ) --> maint - vhigh | 16 | 25.00 % |
| (persons - 2, lug_boot - big, safety - high, class - unacc ) --> maint - med | 16 | 25.00 % |
| (persons - 2, lug_boot - big, safety - low, class - unacc ) --> maint - high | 16 | 25.00 % |
| (persons - 2, lug_boot - big, safety - low, class - unacc ) --> maint - low | 16 | 25.00 % |
| (persons - 2, lug_boot - big, safety - low, class - unacc ) --> maint - vhigh | 16 | 25.00 % |
| (persons - 2, lug_boot - big, safety - low, class - unacc ) --> maint - med | 16 | 25.00 % |
| (persons - 2, lug_boot - big, safety - med, class - unacc ) --> maint - high | 16 | 25.00 % |
| (persons - 2, lug_boot - big, safety - med, class - unacc ) --> maint - low | 16 | 25.00 % |
| (persons - 2, lug_boot - big, safety - med, class - unacc ) --> maint - vhigh | 16 | 25.00 % |
| (persons - 2, lug_boot - big, safety - med, class - unacc ) --> maint - med | 16 | 25.00 % |
| (persons - 2, lug_boot - med, safety - high, class - unacc ) --> maint - high | 16 | 25.00 % |
| (persons - 2, lug_boot - med, safety - high, class - unacc ) --> maint - low | 16 | 25.00 % |
| (persons - 2, lug_boot - med, safety - high, class - unacc ) --> maint - vhigh | 16 | 25.00 % |
| (persons - 2, lug_boot - med, safety - high, class - unacc ) --> maint - med | 16 | 25.00 % |
| (persons - 2, lug_boot - med, safety - low, class - unacc ) --> maint - high | 16 | 25.00 % |
| (persons - 2, lug_boot - med, safety - low, class - unacc ) --> maint - low | 16 | 25.00 % |
| (persons - 2, lug_boot - med, safety - low, class - unacc ) --> maint - vhigh | 16 | 25.00 % |
| (persons - 2, lug_boot - med, safety - low, class - unacc ) --> maint - med | 16 | 25.00 % |
| (persons - 2, lug_boot - med, safety - med, class - unacc ) --> maint - high | 16 | 25.00 % |
| (persons - 2, lug_boot - med, safety - med, class - unacc ) --> maint - low | 16 | 25.00 % |
| (persons - 2, lug_boot - med, safety - med, class - unacc ) --> maint - vhigh | 16 | 25.00 % |
| (persons - 2, lug_boot - med, safety - med, class - unacc ) --> maint - med | 16 | 25.00 % |
| (persons - 4, lug_boot - small, safety - low, class - unacc ) --> maint - high | 16 | 25.00 % |
| (persons - 4, lug_boot - small, safety - low, class - unacc ) --> maint - low | 16 | 25.00 % |
| (persons - 4, lug_boot - small, safety - low, class - unacc ) --> maint - vhigh | 16 | 25.00 % |
| (persons - 4, lug_boot - small, safety - low, class - unacc ) --> maint - med | 16 | 25.00 % |
| (persons - 4, lug_boot - small, safety - med, class - unacc ) --> maint - vhigh | 16 | 36.36 % |
| (persons - 4, lug_boot - big, safety - low, class - unacc ) --> maint - high | 16 | 25.00 % |
| (persons - 4, lug_boot - big, safety - low, class - unacc ) --> maint - low | 16 | 25.00 % |
| (persons - 4, lug_boot - big, safety - low, class - unacc ) --> maint - vhigh | 16 | 25.00 % |
| (persons - 4, lug_boot - big, safety - low, class - unacc ) --> maint - med | 16 | 25.00 % |
| (persons - 4, lug_boot - med, safety - low, class - unacc ) --> maint - high | 16 | 25.00 % |
| (persons - 4, lug_boot - med, safety - low, class - unacc ) --> maint - low | 16 | 25.00 % |
| (persons - 4, lug_boot - med, safety - low, class - unacc ) --> maint - vhigh | 16 | 25.00 % |
| (persons - 4, lug_boot - med, safety - low, class - unacc ) --> maint - med | 16 | 25.00 % |
| (persons - more, lug_boot - small, safety - low, class - unacc ) --> maint - high | 16 | 25.00 % |
| (persons - more, lug_boot - small, safety - low, class - unacc ) --> maint - low | 16 | 25.00 % |
| (persons - more, lug_boot - small, safety - low, class - unacc ) --> maint - vhigh | 16 | 25.00 % |
| (persons - more, lug_boot - small, safety - low, class - unacc ) --> maint - med | 16 | 25.00 % |
| (persons - more, lug_boot - small, safety - med, class - unacc ) --> maint - vhigh | 16 | 32.65 % |
| (persons - more, lug_boot - big, safety - low, class - unacc ) --> maint - high | 16 | 25.00 % |
| (persons - more, lug_boot - big, safety - low, class - unacc ) --> maint - low | 16 | 25.00 % |
| (persons - more, lug_boot - big, safety - low, class - unacc ) --> maint - vhigh | 16 | 25.00 % |
| (persons - more, lug_boot - big, safety - low, class - unacc ) --> maint - med | 16 | 25.00 % |
| (persons - more, lug_boot - med, safety - low, class - unacc ) --> maint - high | 16 | 25.00 % |
| (persons - more, lug_boot - med, safety - low, class - unacc ) --> maint - low | 16 | 25.00 % |
| (persons - more, lug_boot - med, safety - low, class - unacc ) --> maint - vhigh | 16 | 25.00 % |
| (persons - more, lug_boot - med, safety - low, class - unacc ) --> maint - med | 16 | 25.00 % |
<br> `Extraction cannot be done anymore!`
## Computing Action Rules!
### ACTION RULES


 | RULE | SUPPORT | CONFIDENCE |
| -- | -- | -- |
| (class: acc --> good ) --> (maint: vhigh --> low) | 36 | 26.97 %|
| (safety = high, class: acc --> good ) --> (maint: vhigh --> low) | 36 | 26.97 %|
| (safety = med, class: acc --> good ) --> (maint: vhigh --> low) | 36 | 26.97 %|
| (safety = med, class: unacc --> good ) --> (maint: vhigh --> low) | 36 | 26.67 %|
| (lug_boot = big, safety = med, class: unacc --> good ) --> (maint: vhigh --> low) | 36 | 25.00 %|
| (buying: low --> vhigh, class = acc ) --> (maint: vhigh --> low) | 16 | 33.33 %|
| (buying: low --> vhigh, lug_boot = big, class = acc ) --> (maint: vhigh --> low) | 16 | 33.33 %|
| (buying: low --> vhigh, safety = high, class = acc ) --> (maint: vhigh --> low) | 16 | 33.33 %|
| (lug_boot = big, safety = high, class: acc --> vgood ) --> (maint: vhigh --> low) | 16 | 26.67 %|
| (lug_boot = big, safety = med, class: acc --> good ) --> (maint: vhigh --> low) | 16 | 44.44 %|
| (safety = high, class: acc --> vgood ) --> (maint: vhigh --> low) | 23 | 27.88 %|
| (safety = high, class: unacc --> vgood ) --> (maint: vhigh --> low) | 24 | 26.67 %|
